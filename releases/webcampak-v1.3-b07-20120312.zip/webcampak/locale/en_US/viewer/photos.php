<?php 
//<!--{$LANG_PHOTOS_NOPICTURE}-->
$smarty->assign('LANG_PHOTOS_DOWNLOAD_PICTURE', "Downl. Picture");
$smarty->assign('LANG_PHOTOS_DOWNLOAD_ORIGINAL', "Downl. Original");

$smarty->assign('LANG_PHOTOS_PREVIOUS', "Previous");
$smarty->assign('LANG_PHOTOS_NEXT', "Next");

$smarty->assign('LANG_PHOTOS_NOPICTURE', "No picture available for the selected date and time.");


?>