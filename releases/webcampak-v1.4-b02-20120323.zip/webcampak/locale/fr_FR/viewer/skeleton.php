<?php 
$smarty->assign('LANG_SKELETON_BANNERRIGHT_AUTOREFRESH', "Rafraichissement Auto.");
//<!--{$LANG_SKELETON_MENU_PHOTOS}-->
$smarty->assign('LANG_SKELETON_MENU_PHOTOS', "Photos");
$smarty->assign('LANG_SKELETON_MENU_VIDEOS', "Videos");
$smarty->assign('LANG_SKELETON_MENU_THUMBNAILS', "Vignettes");
$smarty->assign('LANG_SKELETON_MENU_AUTOREFRESH', "Maintenant");
$smarty->assign('LANG_SKELETON_MENU_ADMIN', "Admin.");
$smarty->assign('LANG_SKELETON_MENU_MANAGE', "Gestion");
$smarty->assign('LANG_SKELETON_MENU_EXIT', "Quitter");

$smarty->assign('LANG_LOGIN_INDEX', "Bienvenue dans l'interface <a href='http://www.webcampak.com'>Webcampak</a>. <br />
Cliquez sur 'Connexion' pour continuer.<br />");
$smarty->assign('LANG_LOGIN_CONNECT', "Connexion");


?>
