<?php 
$smarty->assign('LANG_CONFIGDEBUT_TITLE', "Configuration file - Source ");
$smarty->assign('LANG_CONFIGDEBUT_CONFIGURATION', "Configuration");

?>