<?php 
$smarty->assign('LANG_REBOOT_TITLE', "Reboot webcampak");
$smarty->assign('LANG_REBOOT_REBOOT', "Reboot");
$smarty->assign('LANG_REBOOT_AREYOUSURE', "Are you sure you want to reboot the system ?");
$smarty->assign('LANG_REBOOT_NOW', "(Reboot now)");



?>