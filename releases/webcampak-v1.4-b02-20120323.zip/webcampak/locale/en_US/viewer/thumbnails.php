<?php 
//<!--{$LANG_THUMBNAILS_NOPICTURE}-->
$smarty->assign('LANG_THUMBNAILS_SOURCE', "Source:");
$smarty->assign('LANG_THUMBNAILS_AVAILABLESIZES', "Available sizes:");
$smarty->assign('LANG_THUMBNAILS_NOPICTURE', "No picture currently available");
$smarty->assign('LANG_THUMBNAILS_SLIDESHOW', "Start slideshow");

?>
