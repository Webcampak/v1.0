<?php
// Copyright 2010 Infracom & Eurotechnia (support@webcampak.com)
// This file is part of the Webcampak project.
// Webcampak is free software: you can redistribute it and/or modify it 
// under the terms of the GNU General Public License as published by 
// the Free Software Foundation, either version 3 of the License, 
// or (at your option) any later version.

// Webcampak is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
// even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.

// You should have received a copy of the GNU General Public License along with Webcampak. 
// If not, see http://www.gnu.org/licenses/.


require("../../etc/admin.config.php");
	//SOURCE 1
	for ($j=1;$j<$config_nbsources;$j++) {
		$dirresultstmp = scandir($config_base . "sources/source" . $j . "/live/");
		$cptpicfiletmp = sizeof($dirresultstmp);
		$cptformat=0;
		for ($i=0;$i<$cptpicfiletmp;$i++) {
			if ($dirresultstmp[$i] != '.' && $dirresultstmp[$i] != '..' && substr($dirresultstmp[$i], -4,4) == ".jpg") {
				if(ereg("webcam",$dirresultstmp[$i])) {
					if ($dirresultstmp[$i] == "webcam.jpg") {
						$livebegsize[$cptformat] = "full";
						$livesize[$cptformat] = "full";	
						$livefilename[$cptformat] = $dirresultstmp[$i];
					} else {
						list($webcamprefix, $livesize[$cptformat]) = explode("-", $dirresultstmp[$i]);
						$livefilename[$cptformat] = $dirresultstmp[$i];
						$livesize[$cptformat] = str_replace(".jpg", "", $livesize[$cptformat]);				
						list($livebegsize[$cptformat], $webcamprefix) = explode("x", $livesize[$cptformat]);		
					}
					$cptformat++;
				}
			}
		}
		$smarty->assign('S' . $j . 'CPTFORMAT', $cptformat);
		$smarty->assign('S' . $j . 'SOURCE', $j);
		$smarty->assign('S' . $j . 'LIVEFILENAME', $livefilename);
		$smarty->assign('S' . $j . 'LIVEFILESIZE', $livesize);
		if ($cptpicfiletmp > 2 && sizeof($livebegsize) > 1) {
			//print_r($livebegsize);
			$smarty->assign('S' . $j . 'LIVEBEGSMALLESTFILESIZE', min($livebegsize));
		}
		$smarty->assign('S' . $j . 'LIVEBEGFILESIZE', $livebegsize);
	}	
	
	
if (is_file($config_langdir . "index.php")) {
	include($config_langdir . "index.php");
}
#$smarty->assign('LOCALE_HELP', $config_directory . 'include/languages/' . $config_lang . '/pages/' . 'locale.help.tpl');
$smarty->assign('CENTRAL', 'index.tpl');
$smarty->display('skeleton.tpl');
?>