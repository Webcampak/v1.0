<?php 
$smarty->assign('LANG_INDEX_TITLE', "Últimas fotografías capturadas");
$smarty->assign('LANG_INDEX_SOURCE_TITLE', "Fuerntes");
$smarty->assign('LANG_INDEX_SOURCE_AVAILABLESIZES', "Tamaños disponibles: ");
$smarty->assign('LANG_INDEX_SOURCE_NOPICTURES', "Ninguna fotografía disponible en este momento");

 


?>