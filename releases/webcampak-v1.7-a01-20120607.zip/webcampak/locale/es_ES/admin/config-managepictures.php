<?php 
$smarty->assign('LANG_MANAGEPICTURES_SOURCE', "Fuente");
$smarty->assign('LANG_MANAGEPICTURES_TITLE', ": Fotografías guardadas");
$smarty->assign('LANG_MANAGEPICTURES_TIP', "Consejo:");
$smarty->assign('LANG_MANAGEPICTURES_DELETE', "Delete");

$smarty->assign('LANG_MANAGEPICTURES_MANAGE', "Administrar imágenes guardadas");
$smarty->assign('LANG_MANAGEPICTURES_DATE', "Fecha");
$smarty->assign('LANG_MANAGEPICTURES_NBPICS', "Número");
$smarty->assign('LANG_MANAGEPICTURES_GLOBALSIZE', "Tamaño total");
$smarty->assign('LANG_MANAGEPICTURES_TOTAL', "TOTAL");
$smarty->assign('LANG_MANAGEPICTURES_TIPCONTENT', "A través de esta página puede eliminar fácilmente un día completo de captura.<br />Si desea eliminiar fotografías concretas, conéctese a Webcampak via FTP.");



?>