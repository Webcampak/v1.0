<?php 
$smarty->assign('LANG_SKELETON_BANNERRIGHT_AUTOREFRESH', "Actualización automática");
//<!--{$LANG_SKELETON_MENU_PHOTOS}-->
$smarty->assign('LANG_SKELETON_MENU_PHOTOS', "Fotografías");
$smarty->assign('LANG_SKELETON_MENU_VIDEOS', "Videos");
$smarty->assign('LANG_SKELETON_MENU_THUMBNAILS', "Thumbnails");
$smarty->assign('LANG_SKELETON_MENU_AUTOREFRESH', "Ahora");
$smarty->assign('LANG_SKELETON_MENU_ADMIN', "Admin.");
$smarty->assign('LANG_SKELETON_MENU_MANAGE', "Gestionar");
$smarty->assign('LANG_SKELETON_MENU_EXIT', "Salir");

$smarty->assign('LANG_LOGIN_INDEX', "Bienvenido a <a href='http://www.webcampak.com'>Webcampak</a> interfaz. <br />
Cliquea en 'Connexion' para continuar.<br />");
$smarty->assign('LANG_LOGIN_CONNECT', "Conectar");

 
?>