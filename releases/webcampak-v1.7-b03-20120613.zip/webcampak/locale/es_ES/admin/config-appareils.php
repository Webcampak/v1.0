<?php 
$smarty->assign('LANG_CONFIGAPPAREILS_TITLE', "Dispositivos conectados");

$smarty->assign('LANG_CONFIGAPPAREILS_GPHOTOCONNECTED', "Cámaras digitales PTP (gphoto2)");
$smarty->assign('LANG_CONFIGAPPAREILS_GPHOTOCAPACITY', "Capacidad de las cámaras digitales PTP (gphoto2)");
$smarty->assign('LANG_CONFIGAPPAREILS_USBDEVICES', "Dispositivos USB (lsusb)");
$smarty->assign('LANG_CONFIGAPPAREILS_VIDEODEVICES', "Dispositivos de video, cámaras web USB (/dev/video...)");
$smarty->assign('LANG_CONFIGAPPAREILS_VIDEODEVICES_ADVANCED', "Opciones avanzadas - Dispositivos de video, cámaras web USB  (/dev/video...)");

   



?>