<?php 
$smarty->assign('LANG_SYSTEMLOGS_TITLE', "System Logs");
$smarty->assign('LANG_SYSTEMLOGS_TIP', "Actions started by users via the administration panel");



?>