<?php 
//<!--{$LANG_VIDEOS_DAILYVID}-->
$smarty->assign('LANG_VIDEOS_DAILYVID', "Video(s) del día:");
$smarty->assign('LANG_VIDEOS_DAILYCREATEDVID', "Video(s) generados este día:");
$smarty->assign('LANG_VIDEOS_DOWNLOADVID', "Descargar video");


$smarty->assign('LANG_VIDEOS_NOPREVIEW', "Previsualización no disponible. <br />Seleccione la opción 'Web' en el panel de administración.");
  					
 

?>