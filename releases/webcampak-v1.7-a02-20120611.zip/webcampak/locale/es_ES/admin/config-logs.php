<?php 
$smarty->assign('LANG_LOGS_SOURCE', "Fuente");
$smarty->assign('LANG_LOGS_TITLE', ": Visualización de registros");
$smarty->assign('LANG_LOGS_TIP', "Consejo:");
 
$smarty->assign('LANG_LOGS_DEBUG', "Depuración extendida");
$smarty->assign('LANG_LOGS_DEBUGACTIVATE', "Habilitar depuración extendida:");
$smarty->assign('LANG_LOGS_DEBUGBUTTON', "Guardar");
$smarty->assign('LANG_LOGS_DEBUGTIP', "Los registros se eliminan automáticamente cada vez que se inicia una nueva captura de video. Esta opción le permite almacenar los registros de forma indefinida.");

$smarty->assign('LANG_LOGS_PICTURES', "Captura de registros");
$smarty->assign('LANG_LOGS_DAILYVID', "Registros diarios de video");
$smarty->assign('LANG_LOGS_CUSTOMVID', "Registros personalizados de video");
$smarty->assign('LANG_LOGS_POSTVID', "Registros Post-Prod.");

?>
