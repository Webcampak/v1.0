<?php 
$smarty->assign('LANG_SKELETON_BANNERRIGHT_AUTOREFRESH', "Auto Refresh");
//<!--{$LANG_SKELETON_MENU_PHOTOS}-->
$smarty->assign('LANG_SKELETON_MENU_PHOTOS', "Photos");
$smarty->assign('LANG_SKELETON_MENU_VIDEOS', "Videos");
$smarty->assign('LANG_SKELETON_MENU_THUMBNAILS', "Thumbnails");
$smarty->assign('LANG_SKELETON_MENU_AUTOREFRESH', "Now");
$smarty->assign('LANG_SKELETON_MENU_ADMIN', "Admin.");
$smarty->assign('LANG_SKELETON_MENU_MANAGE', "Manage");
$smarty->assign('LANG_SKELETON_MENU_EXIT', "Exit");

$smarty->assign('LANG_LOGIN_INDEX', "Welcome into <a href='http://www.webcampak.com'>Webcampak</a> viewer interface. <br />
Clic on 'Connect' to continue.<br />");
$smarty->assign('LANG_LOGIN_CONNECT', "Connect");


?>