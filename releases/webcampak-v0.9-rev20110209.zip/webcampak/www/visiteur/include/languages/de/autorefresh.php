<?php 
//<!--{$LANG_AUTOREFRESH_NOPICTURE}-->
$smarty->assign('LANG_AUTOREFRESH_NOPICTURE', "Image non disponible, veuillez sélectionner un autre résolution ou recharger la page");


?>