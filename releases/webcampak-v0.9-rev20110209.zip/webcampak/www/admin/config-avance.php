<?php
// Copyright 2010 Infracom & Eurotechnia (support@webcampak.com)
// This file is part of the Webcampak project.
// Webcampak is free software: you can redistribute it and/or modify it 
// under the terms of the GNU General Public License as published by 
// the Free Software Foundation, either version 3 of the License, 
// or (at your option) any later version.

// Webcampak is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
// even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.

// You should have received a copy of the GNU General Public License along with Webcampak. 
// If not, see http://www.gnu.org/licenses/.


require("../../etc/config.php");
require("include/zip.lib.php");

$infradmin = "Y";
$smarty->assign('INFRADMIN', $infradmin);

$configsection = strip_tags($_GET['section']);
$smarty->assign('CONFIGSECTION', $configsection);

			//passthru("sudo /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " initconfsources");		 	
		 	//$smarty->assign('POSTINITCONFS1', 'Réinitialisation source 4 ... OK');

		if (strip_tags($_GET['openvpnstart']) == "1") {
			passthru("sudo /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " openvpnstart");		 		
		}
		if (strip_tags($_GET['openvpnstop']) == "1") {
			passthru("sudo /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " openvpnstop");		 				
		}
						
		if (strip_tags($_GET['submit']) == "1") {
		 if (strip_tags($_POST['postinitconfcs']) == "yes"){
		 	$smarty->assign('POSTINITCONF', 'Réinitialisation de la configuration en cours ...');
			passthru("sudo -u " . $config_systemuser . " /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " initconfsources");		 	
		 	$smarty->assign('POSTINITCONFCS', 'Réinitialisation source ' . $config_source . ' ... OK');
			}

			 if (strip_tags($_POST['postinitcontentcs']) == "yes"){
			 	$smarty->assign('POSTINITCONTENT', 'Suppression des images et vidéos en cours ...');
				passthru("sudo -u " . $config_systemuser . " /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " initcontent");		
				$smarty->assign('POSTINITCONTENTCS', 'Réinitialisation source  ' . $config_source . ' ... OK'); 		 
			 }
			 wito_setconfig($config_witoconfig, "cfgemailalertfailure", wito_replacechars(strip_tags($_POST['cfgemailalertfailure'])));
			 wito_setconfig($config_witoconfig, "cfgemailsendto", wito_replacechars(strip_tags($_POST['cfgemailsendto'])));
			 wito_setconfig($config_witoconfig, "cfgemailsendcc", wito_replacechars(strip_tags($_POST['cfgemailsendcc'])));
			 wito_setconfig($config_witoconfig, "cfgemailsendfrom", wito_replacechars(strip_tags($_POST['cfgemailsendfrom'])));
			 wito_setconfig($config_witoconfig, "cfgemailsmtpserver", wito_replacechars(strip_tags($_POST['cfgemailsmtpserver'])));
			 wito_setconfig($config_witoconfig, "cfgemailsmtpauthusername", wito_replacechars(strip_tags($_POST['cfgemailsmtpauthusername'])));
			 wito_setconfig($config_witoconfig, "cfgemailsmtpauthpassword", wito_replacechars(strip_tags($_POST['cfgemailsmtpauthpassword'])));
			
		   if (strip_tags($_POST['cfgemailsmtpauth']) == "yes") {
				wito_setconfig($config_witoconfig, "cfgemailsmtpauth", "yes");	
			} else {
				wito_setconfig($config_witoconfig, "cfgemailsmtpauth", "no");
			}
		   if (strip_tags($_POST['cfgemailsmtpstartttls']) == "yes") {
				wito_setconfig($config_witoconfig, "cfgemailsmtpstartttls", "yes");	
			} else {
				wito_setconfig($config_witoconfig, "cfgemailsmtpstartttls", "no");
			}
						
		}
		if (strip_tags($_GET['upload']) == "1") { 
			if ($_FILES['configupload']['error'] == UPLOAD_ERR_OK) {
				move_uploaded_file($_FILES['configupload']['tmp_name'], $config_etcdirectory. "config-source" . $config_source . ".zip");
				$unzipfiles = unzip($config_etcdirectory. "config-source" . $config_source . ".zip", $config_etcdirectory, true, $config_source);
				if ($unzipfiles != FALSE) {
					$smarty->assign('UPLOADSUCCESSFUL', 'YES');
				}
			}
		}
		$webcamboxconfig = wito_getfullconfig($config_witoconfig);
		
		if ($webcamboxconfig["cfgemailsmtpauth"] == "yes") {
			$smarty->assign('CFGEMAILSMTPAUTH', "checked");
		}
		if ($webcamboxconfig["cfgemailsmtpstartttls"] == "yes") {
			$smarty->assign('CFGEMAILSMTPSTARTTTLS', "checked");
		}
		$smarty->assign('CFGEMAILALERTFAILURE', $webcamboxconfig["cfgemailalertfailure"] );
		$smarty->assign('CFGEMAILSENDTO', $webcamboxconfig["cfgemailsendto"] );		
		$smarty->assign('CFGEMAILSENDCC', $webcamboxconfig["cfgemailsendcc"] );
		$smarty->assign('CFGEMAILSENDFROM', $webcamboxconfig["cfgemailsendfrom"] );
		$smarty->assign('CFGEMAILSMTPSERVER', $webcamboxconfig["cfgemailsmtpserver"] );
		$smarty->assign('CFGEMAILSMTPAUTHUSERNAME', $webcamboxconfig["cfgemailsmtpauthusername"] );
		$smarty->assign('CFGEMAILSMTPAUTHPASSWORD', $webcamboxconfig["cfgemailsmtpauthpassword"] );


if (is_file($config_directory . "include/languages/" . $config_lang . "/config-avance.php")) {
	include($config_directory . "include/languages/" . $config_lang . "/config-avance.php");
}	
//$smarty->assign("BODYCONTENT", $smarty->template_dir . "index.tpl");
$smarty->assign('LOCALE_HELP', $config_directory . 'include/languages/' . $config_lang . '/pages/' . 'locale.help.tpl');
$smarty->assign('CONFIGPAGE', 'avance');
$smarty->assign('CENTRAL', 'config-avance.tpl');
$smarty->display('skeleton.tpl');
//$_COOKIE['lasturl'] = "panel.php"browserurl();



?>