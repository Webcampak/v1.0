<?php
// Copyright 2010 Infracom & Eurotechnia (support@webcampak.com)
// This file is part of the Webcampak project.
// Webcampak is free software: you can redistribute it and/or modify it 
// under the terms of the GNU General Public License as published by 
// the Free Software Foundation, either version 3 of the License, 
// or (at your option) any later version.

// Webcampak is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
// even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.

// You should have received a copy of the GNU General Public License along with Webcampak. 
// If not, see http://www.gnu.org/licenses/.


require("../../etc/config.php");
$infradmin = "Y";
$smarty->assign('INFRADMIN', $infradmin);

$configsection = strip_tags($_GET['section']);
$smarty->assign('CONFIGSECTION', $configsection);

		// WRITE CONFIG
		if (strip_tags($_GET['submit']) == "1") {
		   if (strip_tags($_POST['cfg_notimerestriction']) == "yes") {
				wito_setconfig($config_witoconfig, "cfgcapturestarttime", "no");
				wito_setconfig($config_witoconfig, "cfgcaptureinvert", "no");
			} else {
			   $capturestart = strip_tags($_POST['cfg_capturestarthour']) . strip_tags($_POST['cfg_capturestartminute']);
			   $captureend = strip_tags($_POST['cfg_capturesendhour']) . strip_tags($_POST['cfg_capturesendminute']);
				if ($capturestart < $captureend) {
					wito_setconfig($config_witoconfig, "cfgcapturestarttime", $capturestart);
					wito_setconfig($config_witoconfig, "cfgcaptureendtime", $captureend);
					wito_setconfig($config_witoconfig, "cfgcaptureinvert", "no");
				} else {
					wito_setconfig($config_witoconfig, "cfgcapturestarttime", $captureend);
					wito_setconfig($config_witoconfig, "cfgcaptureendtime", $capturestart);
					wito_setconfig($config_witoconfig, "cfgcaptureinvert", "yes");		
				}
			}
		   if (strip_tags($_POST['cfgimagemagicktxt']) == "yes") {
				wito_setconfig($config_witoconfig, "cfgimagemagicktxt", "yes");	
			} else {
				wito_setconfig($config_witoconfig, "cfgimagemagicktxt", "no");
			}
			wito_setconfig($config_witoconfig, "cfgimgtext", wito_replacechars(stripslashes($_POST['cfg_imgtext'])));		
			wito_setconfig($config_witoconfig, "cfgimgdateformat", strip_tags($_POST['cfg_imgdateformat']));	
			wito_setconfig($config_witoconfig, "cfgcaptureminisize", strip_tags($_POST['cfgcaptureminisize']));
			wito_setconfig($config_witoconfig, "cfgcapturedeleteafterdays", strip_tags($_POST['cfgcapturedeleteafterdays']));
			wito_setconfig($config_witoconfig, "cfgcapturemaxdirsize", strip_tags($_POST['cfgcapturemaxdirsize']));
			wito_setconfig($config_witoconfig, "cfgimgtextsize", wito_replacechars(strip_tags($_POST['cfg_imgtextsize'])));	
			wito_setconfig($config_witoconfig, "cfgimgtextgravity", wito_replacechars(strip_tags($_POST['cfg_imgtextgravity'])));	
			wito_setconfig($config_witoconfig, "cfgimgtextfont", wito_replacechars(strip_tags($_POST['cfg_imgtextfont'])));	
			wito_setconfig($config_witoconfig, "cfgimgtextbasecolor", wito_replacechars(strip_tags($_POST['cfg_imgtextbasecolor'])));	
			wito_setconfig($config_witoconfig, "cfgimgtextbaseposition", wito_replacechars(strip_tags($_POST['cfg_imgtextbaseposition'])));	
			wito_setconfig($config_witoconfig, "cfgimgtextovercolor", wito_replacechars(strip_tags($_POST['cfg_imgtextovercolor'])));	
			wito_setconfig($config_witoconfig, "cfgimgtextoverposition", wito_replacechars(strip_tags($_POST['cfg_imgtextoverposition'])));	

		   if (strip_tags($_POST['cfgpicwatermarkactivate']) == "yes") {
				wito_setconfig($config_witoconfig, "cfgpicwatermarkactivate", "yes");	
			} else {
				wito_setconfig($config_witoconfig, "cfgpicwatermarkactivate", "no");
			}	

			wito_setconfig($config_witoconfig, "cfgpicwatermarkfile", wito_replacechars(strip_tags($_POST['cfgpicwatermarkfile'])));
			wito_setconfig($config_witoconfig, "cfgpicwatermarkdissolve", wito_replacechars(strip_tags($_POST['cfgpicwatermarkdissolve'])));
			wito_setconfig($config_witoconfig, "cfgpicwatermarkpositionx", wito_replacechars(strip_tags($_POST['cfgpicwatermarkpositionx'])));
			wito_setconfig($config_witoconfig, "cfgpicwatermarkpositiony", wito_replacechars(strip_tags($_POST['cfgpicwatermarkpositiony'])));

		   if (strip_tags($_POST['cfgcropactivate']) == "yes") {
				wito_setconfig($config_witoconfig, "cfgcropactivate", "yes");	
			} else {
				wito_setconfig($config_witoconfig, "cfgcropactivate", "no");
			}	
			wito_setconfig($config_witoconfig, "cfgcropsizewidth", wito_replacechars(strip_tags($_POST['cfgcropsizewidth'])));
			wito_setconfig($config_witoconfig, "cfgcropsizeheight", wito_replacechars(strip_tags($_POST['cfgcropsizeheight'])));
			wito_setconfig($config_witoconfig, "cfgcropxpos", wito_replacechars(strip_tags($_POST['cfgcropxpos'])));
			wito_setconfig($config_witoconfig, "cfgcropypos", wito_replacechars(strip_tags($_POST['cfgcropypos'])));

		   if (strip_tags($_POST['cfg_deletelocalpictures']) == "no") {
				wito_setconfig($config_witoconfig, "cfgdeletelocalpictures", "no");	
			} else {
				wito_setconfig($config_witoconfig, "cfgdeletelocalpictures", "yes");
			}
			wito_setconfig($config_witoconfig, "cfgstorepicturesdays", wito_replacechars(strip_tags($_POST['cfgstorepicturesdays'])));
		   if (strip_tags($_POST['cfg_archivesize']) == "yes") {	
				wito_setconfig($config_witoconfig, "cfgarchivesize", strip_tags($_POST['cfg_archivesizeres']));
			} else {
				wito_setconfig($config_witoconfig, "cfgarchivesize", "no");
			}
		   if (strip_tags($_POST['cfgimagemagickres']) == "yes") {
				wito_setconfig($config_witoconfig, "cfgimagemagickres", "yes");	
			} else {
				wito_setconfig($config_witoconfig, "cfgimagemagickres", "no");
			}
			if ( strip_tags($_POST['cfghotlinksize1']) == "autre") {
				wito_setconfig($config_witoconfig, "cfghotlinksize1", strip_tags($_POST['cfghotlinksize1other']));			
			} else {
				wito_setconfig($config_witoconfig, "cfghotlinksize1", strip_tags($_POST['cfghotlinksize1']));			
			}			
//			wito_setconfig($config_witoconfig, "cfghotlinksize1", strip_tags($_POST['cfghotlinksize1']));
			if ( strip_tags($_POST['cfghotlinksize2']) == "autre") {
				wito_setconfig($config_witoconfig, "cfghotlinksize2", strip_tags($_POST['cfghotlinksize2other']));			
			} else {
				wito_setconfig($config_witoconfig, "cfghotlinksize2", strip_tags($_POST['cfghotlinksize2']));			
			}		
//			wito_setconfig($config_witoconfig, "cfghotlinksize2", strip_tags($_POST['cfghotlinksize2']));
			if ( strip_tags($_POST['cfghotlinksize3']) == "autre") {
				wito_setconfig($config_witoconfig, "cfghotlinksize3", strip_tags($_POST['cfghotlinksize3other']));			
			} else {
				wito_setconfig($config_witoconfig, "cfghotlinksize3", strip_tags($_POST['cfghotlinksize3']));			
			}		
//			wito_setconfig($config_witoconfig, "cfghotlinksize3", strip_tags($_POST['cfghotlinksize3']));
			if ( strip_tags($_POST['cfghotlinksize4']) == "autre") {
				wito_setconfig($config_witoconfig, "cfghotlinksize4", strip_tags($_POST['cfghotlinksize4other']));			
			} else {
				wito_setconfig($config_witoconfig, "cfghotlinksize4", strip_tags($_POST['cfghotlinksize4']));			
			}		
//			wito_setconfig($config_witoconfig, "cfghotlinksize4", strip_tags($_POST['cfghotlinksize4']));
						
		}	
		// READ CONFIG	
		$webcamboxconfig = wito_getfullconfig($config_witoconfig);
		if ($webcamboxconfig["cfgcapturestarttime"] == "no") {
			$smarty->assign('CFG_NOTIMERESTRICTION', "checked");
		} else {	
			$tmpcaptureinvert = $webcamboxconfig["cfgcaptureinvert"];
		 	if ($tmpcaptureinvert == "yes") {
		 		$tmpcapturestarttime = $webcamboxconfig["cfgcaptureendtime"];
		 		$tmpcaptureendtime = $webcamboxconfig["cfgcapturestarttime"];		 	
		 	} else {
		 		$tmpcapturestarttime = $webcamboxconfig["cfgcapturestarttime"];
		 		$tmpcaptureendtime = $webcamboxconfig["cfgcaptureendtime"];		 	
		 	}
		 	$smarty->assign('CFG_CAPTURESTARTHOUR', substr($tmpcapturestarttime, -4, 2) );
		 	$smarty->assign('CFG_CAPTURESTARTMINUTE', substr($tmpcapturestarttime, -2, 2) );
		 	$smarty->assign('CFG_CAPTUREENDHOUR', substr($tmpcaptureendtime, -4, 2) );
		 	$smarty->assign('CFG_CAPTUREENDMINUTE', substr($tmpcaptureendtime, -2, 2) );	 
		}
		if ($webcamboxconfig["cfgimagemagicktxt"] == "yes") {
			$smarty->assign('CFGIMAGEMAGICKTXT', "checked");
		}		
		$smarty->assign('CFG_IMGTEXT', $webcamboxconfig["cfgimgtext"] );
		$cfgimgdateformat = $webcamboxconfig["cfgimgdateformat"];
		if ($cfgimgdateformat == "1") {
			$smarty->assign('CFG_IMGDATEFORMAT', "1"); //25/01/2010 - 09h30
		} elseif ($cfgimgdateformat == "2") {
			$smarty->assign('CFG_IMGDATEFORMAT', "2"); //25/01/2010
		} elseif ($cfgimgdateformat == "3") {
			$smarty->assign('CFG_IMGDATEFORMAT', "3"); //09h30
		} elseif ($cfgimgdateformat == "4") {
			$smarty->assign('CFG_IMGDATEFORMAT', "4"); //Thursday 25 January 2010 - 09h30
		} elseif ($cfgimgdateformat == "5") {
			$smarty->assign('CFG_IMGDATEFORMAT', "5"); //25 January 2010 - 09h30
		} else {
			$smarty->assign('CFG_IMGDATEFORMAT', "0");
		}
		if ($webcamboxconfig["cfgdeletelocalpictures"] == "no") {
			$smarty->assign('CFG_DELETELOCALPICTURES', "checked");
		}
		$smarty->assign('CFGSTOREPICTURESDAYS', $webcamboxconfig["cfgstorepicturesdays"] );
		if ($webcamboxconfig["cfgarchivesize"] != "no") {
			$smarty->assign('CFG_ARCHIVESIZE', "checked");
			$smarty->assign('CFG_ARCHIVESIZERES', $webcamboxconfig["cfgarchivesize"] );
		}		
		$smarty->assign('CFGCAPTUREMINISIZE', $webcamboxconfig["cfgcaptureminisize"] );
		$smarty->assign('CFGCAPTUREDELETEAFTERDAYS', $webcamboxconfig["cfgcapturedeleteafterdays"] );
		$smarty->assign('CFGCAPTUREMAXDIRSIZE', $webcamboxconfig["cfgcapturemaxdirsize"] );

		if ($webcamboxconfig["cfgpicwatermarkactivate"] == "yes") {
			$smarty->assign('CFGPICWATERMARKACTIVATE', "checked");
		}
		$smarty->assign('CFGPICWATERMARKFILE', $webcamboxconfig["cfgpicwatermarkfile"] );
		$smarty->assign('CFGPICWATERMARKDISSOLVE', $webcamboxconfig["cfgpicwatermarkdissolve"] );
		$smarty->assign('CFGPICWATERMARKPOSITIONX', $webcamboxconfig["cfgpicwatermarkpositionx"] );
		$smarty->assign('CFGPICWATERMARKPOSITIONY', $webcamboxconfig["cfgpicwatermarkpositiony"] );

		$cfghotlinksize1 = $webcamboxconfig["cfghotlinksize1"];
		if ($cfghotlinksize1 != "no" && $cfghotlinksize1 != "320x240" && $cfghotlinksize1 != "640x480" && $cfghotlinksize1 != "800x600" && $cfghotlinksize1 != "1024x768" && $cfghotlinksize2 != "1280x1024") {
			$smarty->assign('CFGHOTLINKSIZE1', 'autre');
			$smarty->assign('CFGHOTLINKSIZE1OTHER', $cfghotlinksize1);
		} else {
			$smarty->assign('CFGHOTLINKSIZE1', $webcamboxconfig["cfghotlinksize1"] );
		}
//		$smarty->assign('CFG_HOTLINKSIZE1', $webcamboxconfig["cfghotlinksize1") );
		$cfghotlinksize2 = $webcamboxconfig["cfghotlinksize2"];
		if ($cfghotlinksize2 != "no" && $cfghotlinksize2 != "320x240" && $cfghotlinksize2 != "640x480" && $cfghotlinksize2 != "800x600" && $cfghotlinksize2 != "1024x768" && $cfghotlinksize2 != "1280x1024") {
			$smarty->assign('CFGHOTLINKSIZE2', 'autre');
			$smarty->assign('CFGHOTLINKSIZE2OTHER', $cfghotlinksize2);
		} else {
			$smarty->assign('CFGHOTLINKSIZE2', $webcamboxconfig["cfghotlinksize2"] );
		}
//		$smarty->assign('CFG_HOTLINKSIZE2', $webcamboxconfig["cfghotlinksize2") );
		$cfghotlinksize3 = $webcamboxconfig["cfghotlinksize3"];
		if ($cfghotlinksize3 != "no" && $cfghotlinksize3 != "320x240" && $cfghotlinksize3 != "640x480" && $cfghotlinksize3 != "800x600" && $cfghotlinksize3 != "1024x768" && $cfghotlinksize3 != "1280x1024") {
			$smarty->assign('CFGHOTLINKSIZE3', 'autre');
			$smarty->assign('CFGHOTLINKSIZE3OTHER', $cfghotlinksize3);
		} else {
			$smarty->assign('CFGHOTLINKSIZE3', $webcamboxconfig["cfghotlinksize3"] );
		}
//		$smarty->assign('CFG_HOTLINKSIZE3', $webcamboxconfig["cfghotlinksize3") );
		$cfghotlinksize4 = $webcamboxconfig["cfghotlinksize4"];
		if ($cfghotlinksize4 != "no" && $cfghotlinksize4 != "320x240" && $cfghotlinksize4 != "640x480" && $cfghotlinksize4 != "800x600" && $cfghotlinksize4 != "1024x768" && $cfghotlinksize4 != "1280x1024") {
			$smarty->assign('CFGHOTLINKSIZE4', 'autre');
			$smarty->assign('CFGHOTLINKSIZE4OTHER', $cfghotlinksize4);
		} else {
			$smarty->assign('CFGHOTLINKSIZE4', $webcamboxconfig["cfghotlinksize4"] );
		}
//		$smarty->assign('CFG_HOTLINKSIZE4', $webcamboxconfig["cfghotlinksize4") );	
		$smarty->assign('CFG_IMGTEXTSIZE', $webcamboxconfig["cfgimgtextsize"] );
		$smarty->assign('CFG_IMGTEXTGRAVITY', $webcamboxconfig["cfgimgtextgravity"] );
		$smarty->assign('CFG_IMGTEXTFONT', $webcamboxconfig["cfgimgtextfont"] );
		$smarty->assign('CFG_IMGTEXTBASECOLOR', $webcamboxconfig["cfgimgtextbasecolor"] );
		$smarty->assign('CFG_IMGTEXTBASEPOSITION', $webcamboxconfig["cfgimgtextbaseposition"] );
		$smarty->assign('CFG_IMGTEXTOVERCOLOR', $webcamboxconfig["cfgimgtextovercolor"] );
		$smarty->assign('CFG_IMGTEXTOVERPOSITION', $webcamboxconfig["cfgimgtextoverposition"] );
		if ($webcamboxconfig["cfgimagemagickres"] == "yes") {
			$smarty->assign('CFGIMAGEMAGICKRES', "checked");
		}

		if ($webcamboxconfig["cfgcropactivate"] == "yes") {
			$smarty->assign('CFGCROPACTIVATE', "checked");
		}
		$smarty->assign('CFGCROPSIZEWIDTH', $webcamboxconfig["cfgcropsizewidth"] );
		$smarty->assign('CFGCROPSIZEHEIGHT', $webcamboxconfig["cfgcropsizeheight"] );
		$smarty->assign('CFGCROPXPOS', $webcamboxconfig["cfgcropxpos"] );
		$smarty->assign('CFGCROPYPOS', $webcamboxconfig["cfgcropypos"] );

		//cfg_videoavihotlinkupload
		
		//$smarty->assign('CFG_DELETELOCALPICTURES', $webcamboxconfig["cfgdeletelocalpictures") );					

		exec('mogrify -list font | grep Font', $fontlist, $ret); 	
		$cptfonts = sizeof($fontlist);
		for ($i=0;$i<$cptfonts;$i++) {
			$fontlist[$i] = trim(str_replace("Font:", "", $fontlist[$i]));
		}
		$smarty->assign('FONTSLIST', $fontlist);
		$smarty->assign('FONTSCPT', $cptfonts);


$cpthour = 0;
for ($i=-1;$i<23;$i++) { 
	$hourtxt[$cpthour] = $i + 1;
	if ($hourtxt[$cpthour] < 10) {
		$hourtxt[$cpthour] = "0" . $hourtxt[$cpthour];
	}
	$cpthour++;
}
$smarty->assign('CPTHOUR', $cpthour);
$smarty->assign('HOURTXT', $hourtxt);

$cptminute = 0;
for ($i=-1;$i<59;$i++) {
	$minutetxt[$cptminute] = $i + 1;
	if ($minutetxt[$cptminute] < 10) {
		$minutetxt[$cptminute] = "0" . $minutetxt[$cptminute];
	}	
	$cptminute++;
}
$smarty->assign('CPTMINUTE', $cptminute);
$smarty->assign('MINUTETXT', $minutetxt);

$cptwatermark = 0;
$watermarkdir = opendir($config_watermarkdirectory); 
while ($listwatermarkfile = readdir($watermarkdir)) {
   if(is_file($config_watermarkdirectory.$listwatermarkfile) && substr($listwatermarkfile, -4,4) == ".png") {
      //echo "Nom : ".$listwatermarkfile . "<br />";
      $watermarkfiles[$cptwatermark] = $listwatermarkfile;
      $cptwatermark++;
   }
} 
closedir($watermarkdir);
$smarty->assign('CPTWATERMARKFILES', $cptwatermark);
$smarty->assign('WATERMARKFILES', $watermarkfiles);

if (is_file($config_directory . "include/languages/" . $config_lang . "/config-photos.php")) {
	include($config_directory . "include/languages/" . $config_lang . "/config-photos.php");
}
$smarty->assign('LOCALE_HELP', $config_directory . 'include/languages/' . $config_lang . '/pages/' . 'locale.help.tpl');
//$smarty->assign("BODYCONTENT", $smarty->template_dir . "index.tpl");
$smarty->assign('CONFIGPAGE', 'photos');
$smarty->assign('CENTRAL', 'config-photos.tpl');
$smarty->display('skeleton.tpl');
//$_COOKIE['lasturl'] = "panel.php"browserurl();



?>