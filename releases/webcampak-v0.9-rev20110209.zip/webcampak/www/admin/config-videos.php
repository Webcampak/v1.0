<?php
// Copyright 2010 Infracom & Eurotechnia (support@webcampak.com)
// This file is part of the Webcampak project.
// Webcampak is free software: you can redistribute it and/or modify it 
// under the terms of the GNU General Public License as published by 
// the Free Software Foundation, either version 3 of the License, 
// or (at your option) any later version.

// Webcampak is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
// even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.

// You should have received a copy of the GNU General Public License along with Webcampak. 
// If not, see http://www.gnu.org/licenses/.


require("../../etc/config.php");
$infradmin = "Y";
$smarty->assign('INFRADMIN', $infradmin);

$configsection = strip_tags($_GET['section']);
$smarty->assign('CONFIGSECTION', $configsection);

		if (strip_tags($_GET['testconfig']) == "1") {
			passthru("sudo -u " . $config_systemuser . " /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " dailyvidtest");
			$smarty->assign('TESTPARAMETERS', '1' );
		}
		if (strip_tags($_GET['submit']) == "1") {
		   if (strip_tags($_POST['cfg_videoavihotlinkupload']) == "yes") {
				wito_setconfig($config_witoconfigvid, "cfgvideoavihotlinkupload", "yes");	
			} else {
				wito_setconfig($config_witoconfigvid, "cfgvideoavihotlinkupload", "no");
			}
		   if (strip_tags($_POST['cfg_videoflvhotlinkupload']) == "yes") {
				wito_setconfig($config_witoconfigvid, "cfgvideoflvhotlinkupload", "yes");	
			} else {
				wito_setconfig($config_witoconfigvid, "cfgvideoflvhotlinkupload", "no");
			}			
		   if (strip_tags($_POST['cfgvideoyoutubeupload']) == "yes") {
				wito_setconfig($config_witoconfigvid, "cfgvideoyoutubeupload", "yes");	
			} else {
				wito_setconfig($config_witoconfigvid, "cfgvideoyoutubeupload", "no");
			}
		   if (strip_tags($_POST['cfgvideaddaudio']) == "yes") {
				wito_setconfig($config_witoconfigvid, "cfgvideaddaudio", "yes");	
			} else {
				wito_setconfig($config_witoconfigvid, "cfgvideaddaudio", "no");
			}	
		   if (strip_tags($_POST['cfgwatermarkactivate']) == "yes") {
				wito_setconfig($config_witoconfigvid, "cfgwatermarkactivate", "yes");	
			} else {
				wito_setconfig($config_witoconfigvid, "cfgwatermarkactivate", "no");
			}	
			
		   if (strip_tags($_POST['cfgvideopreimagemagicktxt']) == "yes") {
				wito_setconfig($config_witoconfigvid, "cfgvideopreimagemagicktxt", "yes");	
			} else {
				wito_setconfig($config_witoconfigvid, "cfgvideopreimagemagicktxt", "no");
			}	
		   if (strip_tags($_POST['cfgvideopreresize']) == "yes") {
				wito_setconfig($config_witoconfigvid, "cfgvideopreresize", "yes");	
			} else {
				wito_setconfig($config_witoconfigvid, "cfgvideopreresize", "no");
			}
			wito_setconfig($config_witoconfigvid, "cfgvideopreimgtext", wito_replacechars(strip_tags($_POST['cfgvideopreimgtext'])));
			wito_setconfig($config_witoconfigvid, "cfgvideopreimgdateformat", wito_replacechars(strip_tags($_POST['cfgvideopreimgdateformat'])));
			wito_setconfig($config_witoconfigvid, "cfgvideopreimgtextsize", wito_replacechars(strip_tags($_POST['cfgvideopreimgtextsize'])));
			wito_setconfig($config_witoconfigvid, "cfgvideopreimgtextgravity", wito_replacechars(strip_tags($_POST['cfgvideopreimgtextgravity'])));
			wito_setconfig($config_witoconfigvid, "cfgvideopreimgtextfont", wito_replacechars(strip_tags($_POST['cfgvideopreimgtextfont'])));
			wito_setconfig($config_witoconfigvid, "cfgvideopreimgtextbasecolor", wito_replacechars(strip_tags($_POST['cfgvideopreimgtextbasecolor'])));
			wito_setconfig($config_witoconfigvid, "cfgvideopreimgtextbaseposition", wito_replacechars(strip_tags($_POST['cfgvideopreimgtextbaseposition'])));
			wito_setconfig($config_witoconfigvid, "cfgvideopreimgtextovercolor", wito_replacechars(strip_tags($_POST['cfgvideopreimgtextovercolor'])));
			wito_setconfig($config_witoconfigvid, "cfgvideopreimgtextoverposition", wito_replacechars(strip_tags($_POST['cfgvideopreimgtextoverposition'])));
			wito_setconfig($config_witoconfigvid, "cfgvideopreresizeres", wito_replacechars(strip_tags($_POST['cfgvideopreresizeres'])));
								
			//CODEC VIDEO 1
		   if (strip_tags($_POST['cfgvideocodecH2641080pcreate']) == "yes") { wito_setconfig($config_witoconfigvid, "cfgvideocodecH2641080pcreate", "yes"); } else {	wito_setconfig($config_witoconfigvid, "cfgvideocodecH2641080pcreate", "no"); }			
		   if (strip_tags($_POST['cfgvideocodecH2641080pcreateflv']) == "yes") { wito_setconfig($config_witoconfigvid, "cfgvideocodecH2641080pcreateflv", "yes");} else {	wito_setconfig($config_witoconfigvid, "cfgvideocodecH2641080pcreateflv", "no"); }				
		   if (strip_tags($_POST['cfgvideocodecH2641080p2pass']) == "yes") { wito_setconfig($config_witoconfigvid, "cfgvideocodecH2641080p2pass", "yes");	} else {	wito_setconfig($config_witoconfigvid, "cfgvideocodecH2641080p2pass", "no"); }				
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH2641080pfps", wito_replacechars(strip_tags($_POST['cfgvideocodecH2641080pfps'])));
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH2641080pcropy", wito_replacechars(strip_tags($_POST['cfgvideocodecH2641080pcropy'])));
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH2641080peffect", wito_replacechars(strip_tags($_POST['cfgvideocodecH2641080peffect'])));
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH2641080pminsize", wito_replacechars(strip_tags($_POST['cfgvideocodecH2641080pminsize'])) * 1000);

		   if (strip_tags($_POST['cfgvideocodecH264720pcreate']) == "yes") {	wito_setconfig($config_witoconfigvid, "cfgvideocodecH264720pcreate", "yes");} else { wito_setconfig($config_witoconfigvid, "cfgvideocodecH264720pcreate", "no"); }			
		   if (strip_tags($_POST['cfgvideocodecH264720pcreateflv']) == "yes") {	wito_setconfig($config_witoconfigvid, "cfgvideocodecH264720pcreateflv", "yes");} else { wito_setconfig($config_witoconfigvid, "cfgvideocodecH264720pcreateflv", "no"); }				
		   if (strip_tags($_POST['cfgvideocodecH264720p2pass']) == "yes") {	wito_setconfig($config_witoconfigvid, "cfgvideocodecH264720p2pass", "yes");} else {	wito_setconfig($config_witoconfigvid, "cfgvideocodecH264720p2pass", "no"); }				
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH264720pfps", wito_replacechars(strip_tags($_POST['cfgvideocodecH264720pfps'])));
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH264720pcropy", wito_replacechars(strip_tags($_POST['cfgvideocodecH264720pcropy'])));
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH264720peffect", wito_replacechars(strip_tags($_POST['cfgvideocodecH264720peffect'])));
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH264720pminsize", wito_replacechars(strip_tags($_POST['cfgvideocodecH264720pminsize'])) * 1000);

		   if (strip_tags($_POST['cfgvideocodecH264480pcreate']) == "yes") {	wito_setconfig($config_witoconfigvid, "cfgvideocodecH264480pcreate", "yes");} else {	wito_setconfig($config_witoconfigvid, "cfgvideocodecH264480pcreate", "no"); }			
		   if (strip_tags($_POST['cfgvideocodecH264480pcreateflv']) == "yes") {	wito_setconfig($config_witoconfigvid, "cfgvideocodecH264480pcreateflv", "yes");} else {	wito_setconfig($config_witoconfigvid, "cfgvideocodecH264480pcreateflv", "no"); }				
		   if (strip_tags($_POST['cfgvideocodecH264480p2pass']) == "yes") {	wito_setconfig($config_witoconfigvid, "cfgvideocodecH264480p2pass", "yes"); } else {	wito_setconfig($config_witoconfigvid, "cfgvideocodecH264480p2pass", "no"); }				
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH264480pfps", wito_replacechars(strip_tags($_POST['cfgvideocodecH264480pfps'])));
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH264480pcropy", wito_replacechars(strip_tags($_POST['cfgvideocodecH264480pcropy'])));
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH264480peffect", wito_replacechars(strip_tags($_POST['cfgvideocodecH264480peffect'])));
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH264480pminsize", wito_replacechars(strip_tags($_POST['cfgvideocodecH264480pminsize'])) * 1000);

		   if (strip_tags($_POST['cfgvideocodecH264customcreate']) == "yes") {	wito_setconfig($config_witoconfigvid, "cfgvideocodecH264customcreate", "yes");} else {	wito_setconfig($config_witoconfigvid, "cfgvideocodecH264customcreate", "no"); }			
		   if (strip_tags($_POST['cfgvideocodecH264customcreateflv']) == "yes") { wito_setconfig($config_witoconfigvid, "cfgvideocodecH264customcreateflv", "yes");	} else {	wito_setconfig($config_witoconfigvid, "cfgvideocodecH264customcreateflv", "no"); }				
		   if (strip_tags($_POST['cfgvideocodecH264custom2pass']) == "yes") {	wito_setconfig($config_witoconfigvid, "cfgvideocodecH264custom2pass", "yes");	} else {	wito_setconfig($config_witoconfigvid, "cfgvideocodecH264custom2pass", "no"); }				
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH264custombitrate", wito_replacechars(strip_tags($_POST['cfgvideocodecH264custombitrate'])));
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH264customfps", wito_replacechars(strip_tags($_POST['cfgvideocodecH264customfps'])));
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH264customwidth", wito_replacechars(strip_tags($_POST['cfgvideocodecH264customwidth'])));
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH264customheight", wito_replacechars(strip_tags($_POST['cfgvideocodecH264customheight'])));
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH264customcropwidth", wito_replacechars(strip_tags($_POST['cfgvideocodecH264customcropwidth'])));
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH264customcropheight", wito_replacechars(strip_tags($_POST['cfgvideocodecH264customcropheight'])));
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH264customcropx", wito_replacechars(strip_tags($_POST['cfgvideocodecH264customcropx'])));
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH264customcropy", wito_replacechars(strip_tags($_POST['cfgvideocodecH264customcropy'])));
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH264customeffect", wito_replacechars(strip_tags($_POST['cfgvideocodecH264customeffect'])));
			wito_setconfig($config_witoconfigvid, "cfgvideocodecH264customminsize", wito_replacechars(strip_tags($_POST['cfgvideocodecH264customminsize'])) * 1000);

			wito_setconfig($config_witoconfigvid, "cfgcustomvidname", wito_replacechars(strip_tags($_POST['cfgcustomvidname'])));
			wito_setconfig($config_witoconfigvid, "cfgcustomstartday", wito_replacechars(strip_tags($_POST['cfgcustomstartday'])));
			wito_setconfig($config_witoconfigvid, "cfgcustomstartmonth", wito_replacechars(strip_tags($_POST['cfgcustomstartmonth'])));
			wito_setconfig($config_witoconfigvid, "cfgcustomstartyear", wito_replacechars(strip_tags($_POST['cfgcustomstartyear'])));
			wito_setconfig($config_witoconfigvid, "cfgcustomstarthour", wito_replacechars(strip_tags($_POST['cfgcustomstarthour'])));
			wito_setconfig($config_witoconfigvid, "cfgcustomstartminute", wito_replacechars(strip_tags($_POST['cfgcustomstartminute'])));
			wito_setconfig($config_witoconfigvid, "cfgcustomendday", wito_replacechars(strip_tags($_POST['cfgcustomendday'])));
			wito_setconfig($config_witoconfigvid, "cfgcustomendmonth", wito_replacechars(strip_tags($_POST['cfgcustomendmonth'])));
			wito_setconfig($config_witoconfigvid, "cfgcustomendyear", wito_replacechars(strip_tags($_POST['cfgcustomendyear'])));
			wito_setconfig($config_witoconfigvid, "cfgcustomendhour", wito_replacechars(strip_tags($_POST['cfgcustomendhour'])));
			wito_setconfig($config_witoconfigvid, "cfgcustomendminute", wito_replacechars(strip_tags($_POST['cfgcustomendminute'])));
			wito_setconfig($config_witoconfigvid, "cfgcustomactive", wito_replacechars(strip_tags($_POST['cfgcustomactive'])));

			wito_setconfig($config_witoconfigvid, "cfgvideodailyvidname", wito_replacechars(strip_tags($_POST['cfg_videodailyvidname'])));
			wito_setconfig($config_witoconfigvid, "cfgvideoyoutubecategory", wito_replacechars(strip_tags($_POST['cfgvideoyoutubecategory'])));
			wito_setconfig($config_witoconfigvid, "cfgvideoaudiofile", wito_replacechars(strip_tags($_POST['cfgvideoaudiofile'])));

			wito_setconfig($config_witoconfigvid, "cfgwatermarkfile", wito_replacechars(strip_tags($_POST['cfgwatermarkfile'])));
			wito_setconfig($config_witoconfigvid, "cfgwatermarkdissolve", wito_replacechars(strip_tags($_POST['cfgwatermarkdissolve'])));
			wito_setconfig($config_witoconfigvid, "cfgwatermarkpositionx", wito_replacechars(strip_tags($_POST['cfgwatermarkpositionx'])));
			wito_setconfig($config_witoconfigvid, "cfgwatermarkpositiony", wito_replacechars(strip_tags($_POST['cfgwatermarkpositiony'])));
		}
		$webcamboxconfig = wito_getfullconfig($config_witoconfigvid);		
		if ($webcamboxconfig["cfgcreatedailyvideo"] == "yes") {
			$smarty->assign('CFGCREATEDAILYVIDEO', "checked");
		}		
		if ($webcamboxconfig["cfgvideoyoutubeupload"] == "yes") {
			$smarty->assign('CFGVIDEOYOUTUBEUPLOAD', "checked");
		}
		$smarty->assign('CFGVIDEOYOUTUBECATEGORY', $webcamboxconfig["cfgvideoyoutubecategory"] );

		if ($webcamboxconfig["cfgvideoaddaudio"] == "yes") {
			$smarty->assign('CFGVIDEOADDAUDIO', "checked");
		}
		$smarty->assign('CFGVIDEOAUDIOFILE', $webcamboxconfig["cfgvideoaudiofile"] );

		if ($webcamboxconfig["cfgwatermarkactivate"] == "yes") {
			$smarty->assign('CFGWATERMARKACTIVATE', "checked");
		}
		$smarty->assign('CFGWATERMARKFILE', $webcamboxconfig["cfgwatermarkfile"] );
		$smarty->assign('CFGWATERMARKDISSOLVE', $webcamboxconfig["cfgwatermarkdissolve"] );
		$smarty->assign('CFGWATERMARKPOSITIONX', $webcamboxconfig["cfgwatermarkpositionx"] );
		$smarty->assign('CFGWATERMARKPOSITIONY', $webcamboxconfig["cfgwatermarkpositiony"] );

	
		$smarty->assign('CFG_VIDEODAILYVIDNAME', $webcamboxconfig["cfgvideodailyvidname"] );
		$smarty->assign('CFG_STOREVIDEOSDAYS', $webcamboxconfig["cfgstorevideosdays"] );					
		$smarty->assign('CFGVIDEOEFFECT', $webcamboxconfig["cfgvideoeffect"] );

		//PARAMETRES AVANCES
		if ($webcamboxconfig["cfgvideopreimagemagicktxt"] == "yes") {
			$smarty->assign('CFGVIDEOPREIMAGEMAGICKTXT', "checked");
		}			
		if ($webcamboxconfig["cfgvideopreresize"] == "yes") {
			$smarty->assign('CFGVIDEOPRERESIZE', "checked");
		}	
		$smarty->assign('CFGVIDEOPREIMGTEXT', $webcamboxconfig["cfgvideopreimgtext"] );
		$smarty->assign('CFGVIDEOPREIMGDATEFORMAT', $webcamboxconfig["cfgvideopreimgdateformat"] );
		$smarty->assign('CFGVIDEOPREIMGTEXTSIZE', $webcamboxconfig["cfgvideopreimgtextsize"] );
		$smarty->assign('CFGVIDEOPREIMGTEXTGRAVITY', $webcamboxconfig["cfgvideopreimgtextgravity"] );
		$smarty->assign('CFGVIDEOPREIMGTEXTFONT', $webcamboxconfig["cfgvideopreimgtextfont"] );
		$smarty->assign('CFGVIDEOPREIMGTEXTBASECOLOR', $webcamboxconfig["cfgvideopreimgtextbasecolor"] );
		$smarty->assign('CFGVIDEOPREIMGTEXTBASEPOSITION', $webcamboxconfig["cfgvideopreimgtextbaseposition"] );
		$smarty->assign('CFGVIDEOPREIMGTEXTOVERCOLOR', $webcamboxconfig["cfgvideopreimgtextovercolor"] );
		$smarty->assign('CFGVIDEOPREIMGTEXTOVERPOSITION', $webcamboxconfig["cfgvideopreimgtextoverposition"] );
		$smarty->assign('CFGVIDEOPRERESIZERES', $webcamboxconfig["cfgvideopreresizeres"] );
		
		//CODECS
		if ($webcamboxconfig["cfgvideocodecH2641080pcreate"] == "yes") {
			$smarty->assign('CFGVIDEOCODECH2641080PCREATE', "checked");
		}
		if ($webcamboxconfig["cfgvideocodecH2641080pcreateflv"] == "yes") {
			$smarty->assign('CFGVIDEOCODECH2641080PCREATEFLV', "checked");
		}
		if ($webcamboxconfig["cfgvideocodecH2641080p2pass"] == "yes") {
			$smarty->assign('CFGVIDEOCODECH2641080P2PASS', "checked");
		}				
		$smarty->assign('CFGVIDEOCODECH2641080PFPS', $webcamboxconfig["cfgvideocodecH2641080pfps"] );
		$smarty->assign('CFGVIDEOCODECH2641080PWIDTH', $webcamboxconfig["cfgvideocodecH2641080pwidth"] );
		$smarty->assign('CFGVIDEOCODECH2641080PHEIGHT', $webcamboxconfig["cfgvideocodecH2641080pheight"] );
		$smarty->assign('CFGVIDEOCODECH2641080PBITRATE', $webcamboxconfig["cfgvideocodecH2641080pbitrate"] );
		$smarty->assign('CFGVIDEOCODECH2641080PCROPHEIGHT', $webcamboxconfig["cfgvideocodecH2641080pcropheight"] );
		$smarty->assign('CFGVIDEOCODECH2641080PCROPWIDTH', $webcamboxconfig["cfgvideocodecH2641080pcropwidth"] );
		$smarty->assign('CFGVIDEOCODECH2641080PCROPX', $webcamboxconfig["cfgvideocodecH2641080pcropx"] );
		$smarty->assign('CFGVIDEOCODECH2641080PCROPY', $webcamboxconfig["cfgvideocodecH2641080pcropy"] );
		$smarty->assign('CFGVIDEOCODECH2641080PEFFECT', $webcamboxconfig["cfgvideocodecH2641080peffect"] );
		$smarty->assign('CFGVIDEOCODECH2641080PMINSIZE', round($webcamboxconfig["cfgvideocodecH2641080pminsize"]/1000) );

		if ($webcamboxconfig["cfgvideocodecH264720pcreate"] == "yes") {
			$smarty->assign('CFGVIDEOCODECH264720PCREATE', "checked");
		}
		if ($webcamboxconfig["cfgvideocodecH264720pcreateflv"] == "yes") {
			$smarty->assign('CFGVIDEOCODECH264720PCREATEFLV', "checked");
		}
		if ($webcamboxconfig["cfgvideocodecH264720p2pass"] == "yes") {
			$smarty->assign('CFGVIDEOCODECH264720P2PASS', "checked");
		}				
		$smarty->assign('CFGVIDEOCODECH264720PFPS', $webcamboxconfig["cfgvideocodecH264720pfps"] );
		$smarty->assign('CFGVIDEOCODECH264720PWIDTH', $webcamboxconfig["cfgvideocodecH264720pwidth"] );
		$smarty->assign('CFGVIDEOCODECH264720PHEIGHT', $webcamboxconfig["cfgvideocodecH264720pheight"] );
		$smarty->assign('CFGVIDEOCODECH264720PBITRATE', $webcamboxconfig["cfgvideocodecH264720pbitrate"] );
		$smarty->assign('CFGVIDEOCODECH264720PCROPHEIGHT', $webcamboxconfig["cfgvideocodecH264720pcropheight"] );
		$smarty->assign('CFGVIDEOCODECH264720PCROPWIDTH', $webcamboxconfig["cfgvideocodecH264720pcropwidth"] );
		$smarty->assign('CFGVIDEOCODECH264720PCROPX', $webcamboxconfig["cfgvideocodecH264720pcropx"] );
		$smarty->assign('CFGVIDEOCODECH264720PCROPY', $webcamboxconfig["cfgvideocodecH264720pcropy"] );
		$smarty->assign('CFGVIDEOCODECH264720PEFFECT', $webcamboxconfig["cfgvideocodecH264720peffect"] );
		$smarty->assign('CFGVIDEOCODECH264720PMINSIZE', round($webcamboxconfig["cfgvideocodecH264720pminsize"]/1000) );

		if ($webcamboxconfig["cfgvideocodecH264480pcreate"] == "yes") {
			$smarty->assign('CFGVIDEOCODECH264480PCREATE', "checked");
		}
		if ($webcamboxconfig["cfgvideocodecH264480pcreateflv"] == "yes") {
			$smarty->assign('CFGVIDEOCODECH264480PCREATEFLV', "checked");
		}
		if ($webcamboxconfig["cfgvideocodecH264480p2pass"] == "yes") {
			$smarty->assign('CFGVIDEOCODECH264480P2PASS', "checked");
		}				
		$smarty->assign('CFGVIDEOCODECH264480PFPS', $webcamboxconfig["cfgvideocodecH264480pfps"] );
		$smarty->assign('CFGVIDEOCODECH264480PWIDTH', $webcamboxconfig["cfgvideocodecH264480pwidth"] );
		$smarty->assign('CFGVIDEOCODECH264480PHEIGHT', $webcamboxconfig["cfgvideocodecH264480pheight"] );
		$smarty->assign('CFGVIDEOCODECH264480PBITRATE', $webcamboxconfig["cfgvideocodecH264480pbitrate"] );
		$smarty->assign('CFGVIDEOCODECH264480PCROPHEIGHT', $webcamboxconfig["cfgvideocodecH264480pcropheight"] );
		$smarty->assign('CFGVIDEOCODECH264480PCROPWIDTH', $webcamboxconfig["cfgvideocodecH264480pcropwidth"] );
		$smarty->assign('CFGVIDEOCODECH264480PCROPX', $webcamboxconfig["cfgvideocodecH264480pcropx"] );
		$smarty->assign('CFGVIDEOCODECH264480PCROPY', $webcamboxconfig["cfgvideocodecH264480pcropy"] );
		$smarty->assign('CFGVIDEOCODECH264480PEFFECT', $webcamboxconfig["cfgvideocodecH264480peffect"] );
		$smarty->assign('CFGVIDEOCODECH264480PMINSIZE', round($webcamboxconfig["cfgvideocodecH264480pminsize"]/1000) );

		if ($webcamboxconfig["cfgvideocodecH264customcreate"] == "yes") {
			$smarty->assign('CFGVIDEOCODECH264CUSTOMCREATE', "checked");
		}
		if ($webcamboxconfig["cfgvideocodecH264customcreateflv"] == "yes") {
			$smarty->assign('CFGVIDEOCODECH264CUSTOMCREATEFLV', "checked");
		}
		if ($webcamboxconfig["cfgvideocodecH264custom2pass"] == "yes") {
			$smarty->assign('CFGVIDEOCODECH264CUSTOM2PASS', "checked");
		}				
		$smarty->assign('CFGVIDEOCODECH264CUSTOMFPS', $webcamboxconfig["cfgvideocodecH264customfps"] );
		$smarty->assign('CFGVIDEOCODECH264CUSTOMWIDTH', $webcamboxconfig["cfgvideocodecH264customwidth"] );
		$smarty->assign('CFGVIDEOCODECH264CUSTOMHEIGHT', $webcamboxconfig["cfgvideocodecH264customheight"] );
		$smarty->assign('CFGVIDEOCODECH264CUSTOMBITRATE', $webcamboxconfig["cfgvideocodecH264custombitrate"] );
		$smarty->assign('CFGVIDEOCODECH264CUSTOMCROPWIDTH', $webcamboxconfig["cfgvideocodecH264customcropwidth"] );
		$smarty->assign('CFGVIDEOCODECH264CUSTOMCROPHEIGHT', $webcamboxconfig["cfgvideocodecH264customcropheight"] );
		$smarty->assign('CFGVIDEOCODECH264CUSTOMCROPX', $webcamboxconfig["cfgvideocodecH264customcropx"] );
		$smarty->assign('CFGVIDEOCODECH264CUSTOMCROPY', $webcamboxconfig["cfgvideocodecH264customcropy"] );
		$smarty->assign('CFGVIDEOCODECH264CUSTOMEFFECT', $webcamboxconfig["cfgvideocodecH264customeffect"] );
		$smarty->assign('CFGVIDEOCODECH264CUSTOMMINSIZE', round($webcamboxconfig["cfgvideocodecH264customminsize"]/1000) );
			
		$smarty->assign('CFGCUSTOMVIDNAME', $webcamboxconfig["cfgcustomvidname"] );
		$smarty->assign('CFGCUSTOMSTARTDAY', $webcamboxconfig["cfgcustomstartday"] );
		$smarty->assign('CFGCUSTOMSTARTMONTH', $webcamboxconfig["cfgcustomstartmonth"] );
		$smarty->assign('CFGCUSTOMSTARTYEAR', $webcamboxconfig["cfgcustomstartyear"] );
		$smarty->assign('CFGCUSTOMSTARTHOUR', $webcamboxconfig["cfgcustomstarthour"] );
		$smarty->assign('CFGCUSTOMSTARTMINUTE', $webcamboxconfig["cfgcustomstartminute"] );
		$smarty->assign('CFGCUSTOMENDDAY', $webcamboxconfig["cfgcustomendday"] );
		$smarty->assign('CFGCUSTOMENDMONTH', $webcamboxconfig["cfgcustomendmonth"] );
		$smarty->assign('CFGCUSTOMENDYEAR', $webcamboxconfig["cfgcustomendyear"] );
		$smarty->assign('CFGCUSTOMENDHOUR', $webcamboxconfig["cfgcustomendhour"] );
		$smarty->assign('CFGCUSTOMENDMINUTE', $webcamboxconfig["cfgcustomendminute"] );
		$smarty->assign('CFGCUSTOMACTIVE', $webcamboxconfig["cfgcustomactive"] );

$cptday = 0;
for ($i=0;$i<31;$i++) { 
	$daytxt[$cptday] = $i + 1;
	if ($daytxt[$cptday] < 10) {
		$daytxt[$cptday] = "0" . $daytxt[$cptday];
	}
	$cptday++;
}
$smarty->assign('CPTDAY', $cptday);
$smarty->assign('DAYTXT', $daytxt);

$cptyear = 0;
for ($i=2005;$i<2020;$i++) { 
	$yeartxt[$cptyear] = $i + 1;
	$cptyear++;
}
$smarty->assign('CPTYEAR', $cptyear);
$smarty->assign('YEARTXT', $yeartxt);

$cpthour = 0;
for ($i=-1;$i<23;$i++) { 
	$hourtxt[$cpthour] = $i + 1;
	if ($hourtxt[$cpthour] < 10) {
		$hourtxt[$cpthour] = "0" . $hourtxt[$cpthour];
	}
	$cpthour++;
}
$smarty->assign('CPTHOUR', $cpthour);
$smarty->assign('HOURTXT', $hourtxt);

$cptminute = 0;
for ($i=-1;$i<59;$i++) {
	$minutetxt[$cptminute] = $i + 1;
	if ($minutetxt[$cptminute] < 10) {
		$minutetxt[$cptminute] = "0" . $minutetxt[$cptminute];
	}	
	$cptminute++;
}
$smarty->assign('CPTMINUTE', $cptminute);
$smarty->assign('MINUTETXT', $minutetxt);

exec('mogrify -list font | grep Font', $fontlist, $ret); 	
$cptfonts = sizeof($fontlist);
for ($i=0;$i<$cptfonts;$i++) {
	$fontlist[$i] = trim(str_replace("Font:", "", $fontlist[$i]));
}
$smarty->assign('FONTSLIST', $fontlist);
$smarty->assign('FONTSCPT', $cptfonts);

$cptaudio = 0;
$audiodir = opendir($config_audiodirectory); 
while ($listaudiofile = readdir($audiodir)) {
   if(is_file($config_audiodirectory.$listaudiofile) && (substr($listaudiofile, -4,4) == ".mp3" || substr($listaudiofile, -4,4) == ".m3u")) {
      //echo "Nom : ".$listaudiofile . "<br />";
      $audiofiles[$cptaudio] = $listaudiofile;
      $cptaudio++;
   }
} 
closedir($audiodir);
$smarty->assign('CPTAUDIOFILES', $cptaudio);
$smarty->assign('AUDIOFILES', $audiofiles);

$cptwatermark = 0;
$watermarkdir = opendir($config_watermarkdirectory); 
while ($listwatermarkfile = readdir($watermarkdir)) {
   if(is_file($config_watermarkdirectory.$listwatermarkfile) && substr($listwatermarkfile, -4,4) == ".png") {
      //echo "Nom : ".$listwatermarkfile . "<br />";
      $watermarkfiles[$cptwatermark] = $listwatermarkfile;
      $cptwatermark++;
   }
} 
closedir($watermarkdir);
$smarty->assign('CPTWATERMARKFILES', $cptwatermark);
$smarty->assign('WATERMARKFILES', $watermarkfiles);

if (is_file($config_directory . "include/languages/" . $config_lang . "/config-videos.php")) {
	include($config_directory . "include/languages/" . $config_lang . "/config-videos.php");
}

$smarty->assign('LOCALE_HELP', $config_directory . 'include/languages/' . $config_lang . '/pages/' . 'locale.help.tpl');
//$smarty->assign("BODYCONTENT", $smarty->template_dir . "index.tpl");
$smarty->assign('CONFIGPAGE', 'videos');
$smarty->assign('CENTRAL', 'config-videos.tpl');
$smarty->display('skeleton.tpl');
//$_COOKIE['lasturl'] = "panel.php"browserurl();

?>