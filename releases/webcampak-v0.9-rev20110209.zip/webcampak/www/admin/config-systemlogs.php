<?php
// Copyright 2010 Infracom & Eurotechnia (support@webcampak.com)
// This file is part of the Webcampak project.
// Webcampak is free software: you can redistribute it and/or modify it 
// under the terms of the GNU General Public License as published by 
// the Free Software Foundation, either version 3 of the License, 
// or (at your option) any later version.

// Webcampak is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
// even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.

// You should have received a copy of the GNU General Public License along with Webcampak. 
// If not, see http://www.gnu.org/licenses/.


require("../../etc/config.php");
$infradmin = "Y";
$smarty->assign('INFRADMIN', $infradmin);

$configsection = strip_tags($_GET['section']);
$smarty->assign('CONFIGSECTION', $configsection);

		if (is_file($config_logdirectory . "passthru.log")) {		
			$displayphotolog = file_get_contents($config_logdirectory . "passthru.log");
			$smarty->assign('DISP_CACHEARCHIVES', $displayphotolog);
		}

if (is_file($config_directory . "include/languages/" . $config_lang . "/config-systemlogs.php")) {
	include($config_directory . "include/languages/" . $config_lang . "/config-systemlogs.php");
}

$smarty->assign('LOCALE_HELP', $config_directory . 'include/languages/' . $config_lang . '/pages/' . 'locale.help.tpl');
$smarty->assign('CONFIGSYSTEM', '1');
$smarty->assign('CONFIGPAGE', 'systemlogs');
$smarty->assign('CONFIGSOURCE', '0');
$smarty->assign('CENTRAL', 'config-systemlogs.tpl');
$smarty->display('skeleton.tpl');
//$_COOKIE['lasturl'] = "panel.php"browserurl();



?>