<?php
// Copyright 2010 Infracom & Eurotechnia (support@webcampak.com)
// This file is part of the Webcampak project.
// Webcampak is free software: you can redistribute it and/or modify it 
// under the terms of the GNU General Public License as published by 
// the Free Software Foundation, either version 3 of the License, 
// or (at your option) any later version.

// Webcampak is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
// even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.

// You should have received a copy of the GNU General Public License along with Webcampak. 
// If not, see http://www.gnu.org/licenses/.


require("../../etc/config.php");
$infradmin = "Y";
$smarty->assign('INFRADMIN', $infradmin);

$configsection = strip_tags($_GET['section']);
$smarty->assign('CONFIGSECTION', $configsection);

	//passthru('echo testee | sudo /usr/bin/php -f ' . $config_bindirectory . 'server.php'); 
	if (strip_tags($_GET['capture']) == "1") {
		//Lancer la capture de l'image
		passthru("sudo -u " . $config_systemuser . " /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " sample");
		$smarty->assign('DSIPLAYCAPTURE', '1' );
	}
	if (strip_tags($_GET['capturerecord']) == "1") {
		//Lancer la capture de l'image
		passthru("sudo -u " . $config_systemuser . " /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " samplerecord");
		$smarty->assign('DSIPLAYCAPTURE', '1' );
	}	
	
	if (strip_tags($_GET['gphotoassign']) == "1") {
		passthru("sudo -u " . $config_systemuser . " /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " gphotoassign");
		$smarty->assign('GPHOTOASSIGNAPPLIED', '1' );
	}	
	
	$webcamboxconfig = wito_getfullconfig($config_witoconfig);
	$config_cambase = $webcamboxconfig["cfgbasedir"];
	$smarty->assign('WITODISKSPACE', wito_diskspace($config_base));
		//MODIFICATION DES PARAMETRES		
		if (strip_tags($_GET['submit']) == "1") {
		   if (strip_tags($_POST['cfgsourceactive']) == "yes") {
				wito_setconfig($config_witoconfig, "cfgsourceactive", "yes");	
			} else {
				wito_setconfig($config_witoconfig, "cfgsourceactive", "no");
			}
			wito_setconfig($config_witoconfig, "cfgsourcetype", strip_tags($_POST['cfgsourcetype']));
		   if (strip_tags($_POST['cfgsourcedebug']) == "yes") {
				wito_setconfig($config_witoconfig, "cfgsourcedebug", "yes");	
			} else {
				wito_setconfig($config_witoconfig, "cfgsourcedebug", "no");
			}
		   if (strip_tags($_POST['cfgemailerroractivate']) == "yes") {
				wito_setconfig($config_witoconfig, "cfgemailerroractivate", "yes");	
			} else {
				wito_setconfig($config_witoconfig, "cfgemailerroractivate", "no");
			}			
		   if (strip_tags($_POST['cfgnocapture']) == "yes") {
				wito_setconfig($config_witoconfig, "cfgnocapture", "yes");	
			} else {
				wito_setconfig($config_witoconfig, "cfgnocapture", "no");
			}				
		   //if (strip_tags($_POST['cfgsourcegphotocamera']) == "yes") {
			//	wito_setconfig($config_witoconfig, "cfgsourcegphotocamera", "yes");	
			//} else {
			//	wito_setconfig($config_witoconfig, "cfgsourcegphotocamera", "no");
			//}
			if (strip_tags($_POST['cfgsourcegphotocameramodel']) == ""){
				wito_setconfig($config_witoconfig, "cfgsourcegphotocameramodel", "no");		
			} else {
				wito_setconfig($config_witoconfig, "cfgsourcegphotocameramodel", strip_tags($_POST['cfgsourcegphotocameramodel']));
			}
		   //if (strip_tags($_POST['cfgsourcegphotocameraport']) == "yes") {
			//	wito_setconfig($config_witoconfig, "cfgsourcegphotocameraport", "yes");	
			//} else {
			//	wito_setconfig($config_witoconfig, "cfgsourcegphotocameraport", "no");
			//}
		   if (strip_tags($_POST['cfgsourcegphotocalibration']) == "yes") {
				wito_setconfig($config_witoconfig, "cfgsourcegphotocalibration", "yes");	
			} else {
				wito_setconfig($config_witoconfig, "cfgsourcegphotocalibration", "no");
			}			
		   if (strip_tags($_POST['cfgsourcecamiplimiterotation']) == "yes") {
				wito_setconfig($config_witoconfig, "cfgsourcecamiplimiterotation", "yes");	
			} else {
				wito_setconfig($config_witoconfig, "cfgsourcecamiplimiterotation", "no");
			}							
			wito_setconfig($config_witoconfig, "cfgsourcegphotocameraportdetail", strip_tags($_POST['cfgsourcegphotocameraportdetail']));
			wito_setconfig($config_witoconfig, "cfgsourcegphotoowner", trim(strip_tags($_POST['cfgsourcegphotoowner'])));
			if ( strip_tags($_POST['cfgsourcewebcamsize']) == "autre") {
				wito_setconfig($config_witoconfig, "cfgsourcewebcamsize", strip_tags($_POST['cfgsourcewebcamsizeother']));			
			} else {
				wito_setconfig($config_witoconfig, "cfgsourcewebcamsize", strip_tags($_POST['cfgsourcewebcamsize']));			
			}
			wito_setconfig($config_witoconfig, "cfgsourcewebcamquality", strip_tags($_POST['cfgsourcewebcamquality']));						
			wito_setconfig($config_witoconfig, "cfgsourcewebcamcamid", strip_tags($_POST['cfgsourcewebcamcamid']));
			wito_setconfig($config_witoconfig, "cfgsourcewebcambright", strip_tags($_POST['cfgsourcewebcambright']));
			wito_setconfig($config_witoconfig, "cfgsourcewebcamcontrast", strip_tags($_POST['cfgsourcewebcamcontrast']));
			wito_setconfig($config_witoconfig, "cfgsourcewebcamcolor", strip_tags($_POST['cfgsourcewebcamcolor']));
			wito_setconfig($config_witoconfig, "cfgsourcewebcamhue", strip_tags($_POST['cfgsourcewebcamhue']));

			wito_setconfig($config_witoconfig, "cfgminimumcapturevalue", strip_tags($_POST['cfgminimumcapturevalue']));
			wito_setconfig($config_witoconfig, "cfgminimumcaptureinterval", strip_tags($_POST['cfgminimumcaptureinterval']));
			/*			
			wito_setconfig($config_witoconfig, "cfgsourcewebcamgamma", strip_tags($_POST['cfgsourcewebcamgamma']));
			wito_setconfig($config_witoconfig, "cfgsourcewebcamgain", strip_tags($_POST['cfgsourcewebcamgain']));
			wito_setconfig($config_witoconfig, "cfgsourcewebcamsharpness", strip_tags($_POST['cfgsourcewebcamsharpness']));
			*/
			wito_setconfig($config_witoconfig, "cfgsourcecamiptemplate", strip_tags($_POST['cfgsourcecamiptemplate']));
			wito_setconfig($config_witoconfig, "cfgsourcewebfileurl", strip_tags($_POST['cfgsourcewebfileurl']));
		}
		//LECTURE DES PARAMETRES
		$webcamboxconfig = wito_getfullconfig($config_witoconfig);
		if ($webcamboxconfig["cfgsourceactive"] == "yes") {
			$smarty->assign('CFGSOURCEACTIVE', "checked");
		}
		$smarty->assign('CFGSOURCETYPE', $webcamboxconfig["cfgsourcetype"] );
		if ($webcamboxconfig["cfgsourcedebug"] == "yes") {
			$smarty->assign('CFGSOURCEDEBUG', "checked");
		}
		if ($webcamboxconfig["cfgemailerroractivate"] == "yes") {
			$smarty->assign('CFGEMAILERRORACTIVATE', "checked");
		}		
		//if ($webcamboxconfig["cfgsourcegphotocamera"] == "yes") {
		//	$smarty->assign('CFGSOURCEGPHOTOCAMERA', "checked");
		//}
		if ($webcamboxconfig["cfgsourcegphotocalibration"] == "yes") {
			$smarty->assign('CFGSOURCEGPHOTOCALIBRATION', "checked");
		}		
		if ($webcamboxconfig["cfgsourcecamiplimiterotation"] == "yes") {
			$smarty->assign('CFGSOURCECAMIPLIMITEROTATION', "checked");
		}	
		if ($webcamboxconfig["cfgnocapture"] == "yes") {
			$smarty->assign('CFGNOCAPTURE', "checked");
		}	
		//if ($webcamboxconfig["cfgsourcegphotocameraport"] == "yes") {
		//	$smarty->assign('CFGSOURCEGPHOTOCAMERAPORT', "checked");
		//}				
			
		$cfgsourcegphotocameramodel = $webcamboxconfig["cfgsourcegphotocameramodel"];
		if ($cfgsourcegphotocameramodel == "no") {
			$smarty->assign('CFGSOURCEGPHOTOCAMERAMODEL', "");
		} else {
			$smarty->assign('CFGSOURCEGPHOTOCAMERAMODEL', $webcamboxconfig["cfgsourcegphotocameramodel"] );		
		}
		$cfgsourcegphotocameraportdetail = $webcamboxconfig["cfgsourcegphotocameraportdetail"];
		if ($cfgsourcegphotocameraportdetail == "automatic") {
			$smarty->assign('CFGSOURCEGPHOTOCAMERAPORTDETAIL', "automatique");
		} else {
			$smarty->assign('CFGSOURCEGPHOTOCAMERAPORTDETAIL', $webcamboxconfig["cfgsourcegphotocameraportdetail"] );		
		}		
		//$smarty->assign('CFGSOURCEGPHOTOCAMERAPORT', $webcamboxconfig["cfgsourcegphotocameraport"] );
		//$smarty->assign('CFGSOURCEGPHOTOCAMERAPORTDETAIL', $webcamboxconfig["cfgsourcegphotocameraportdetail"] );		
		$smarty->assign('CFGSOURCEGPHOTOOWNER', $webcamboxconfig["cfgsourcegphotoowner"] );
		$cfgsourcewebcamsize = $webcamboxconfig["cfgsourcewebcamsize"];
		if ($cfgsourcewebcamsize != "320x240" && $cfgsourcewebcamsize != "640x480" && $cfgsourcewebcamsize != "800x600" && $cfgsourcewebcamsize != "1024x768" && $cfgsourcewebcamsize != "1280x1024" && $cfgsourcewebcamsize != "1600x1200") {
			$smarty->assign('CFGSOURCEWEBCAMSIZE', 'autre');
			$smarty->assign('CFGSOURCEWEBCAMSIZEOTHER', $cfgsourcewebcamsize);
		} else {
			$smarty->assign('CFGSOURCEWEBCAMSIZE', $webcamboxconfig["cfgsourcewebcamsize"] );
		}
		$smarty->assign('CFGSOURCEWEBCAMQUALITY', $webcamboxconfig["cfgsourcewebcamquality"] );
		$cfgsourcewebcamid = $webcamboxconfig["cfgsourcewebcamcamid"];
		$smarty->assign('CFGSOURCEWEBCAMID', $cfgsourcewebcamid);
		$trans = array("video" => "", "dev" => "", "/" => "");
		$cfgsourcewebcamidnb = strtr($cfgsourcewebcamid, $trans);
		$cfgsourcewebcamidnb = $cfgsourcewebcamidnb * 1;
		//echo "WEBCAMIDNB: $cfgsourcewebcamidnb";	
		$smarty->assign('CFGSOURCEWEBCAMBRIGHT', $webcamboxconfig["cfgsourcewebcambright"] );					
		$smarty->assign('CFGSOURCEWEBCAMCONTRAST', $webcamboxconfig["cfgsourcewebcamcontrast"] );					
		$smarty->assign('CFGSOURCEWEBCAMCOLOR', $webcamboxconfig["cfgsourcewebcamcolor"] );					
		$smarty->assign('CFGSOURCEWEBCAMHUE', $webcamboxconfig["cfgsourcewebcamhue"] );					

		$smarty->assign('CFGMINIMUMCAPTUREVALUE', $webcamboxconfig["cfgminimumcapturevalue"] );					
		$smarty->assign('CFGMINIMUMCAPTUREINTERVAL', $webcamboxconfig["cfgminimumcaptureinterval"] );					

		/*			
		$smarty->assign('CFGSOURCEWEBCAMGAMMA', $webcamboxconfig["cfgsourcewebcamgamma") );					
		$smarty->assign('CFGSOURCEWEBCAMGAIN', $webcamboxconfig["cfgsourcewebcamgain") );					
		$smarty->assign('CFGSOURCEWEBCAMSHARPNESS', $webcamboxconfig["cfgsourcewebcamsharpness") );	
		*/
		$smarty->assign('CFGSOURCECAMIPTEMPLATE', $webcamboxconfig["cfgsourcecamiptemplate"] );	
		$smarty->assign('CFGSOURCEWEBFILEURL', $webcamboxconfig["cfgsourcewebfileurl"] );
		
		if ($webcamboxconfig["cfgsourcetype"] == "webcam") {
			// Recuperation des parametres par défaut pour la webcam usb
			passthru("sudo -u " . $config_systemuser . " /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " v4lunique");
			$fd = @fopen("/tmp/v4lctl" . $cfgsourcewebcamidnb ,"r");
			if (!$fd) die("Erreur ouverture fichier: $fd");
			$i = 1; // compteur de ligne
			while (!feof($fd)) {
				$ligne = fgets($fd, 1024);
				if (stripos($ligne, $witoget . "bright") !== false) {
					list($webcamattribute, $webcamtype, $webcamcurrent, $webcamdefault, $webcamcomment) = explode("|", $ligne);
					$smarty->assign('CFGSOURCEWEBCAMBRIGHTATTRIBUTE', $webcamattribute);
					$smarty->assign('CFGSOURCEWEBCAMBRIGHTCURRENT', $webcamcurrent);
					$smarty->assign('CFGSOURCEWEBCAMBRIGHTDEFAULT', $webcamdefault);
					$smarty->assign('CFGSOURCEWEBCAMBRIGHTCOMMENT', $webcamcomment);		
				}			
				if (stripos($ligne, $witoget . "contrast") !== false) {
					list($webcamattribute, $webcamtype, $webcamcurrent, $webcamdefault, $webcamcomment) = explode("|", $ligne);
					$smarty->assign('CFGSOURCEWEBCAMCONTRASTATTRIBUTE', $webcamattribute);
					$smarty->assign('CFGSOURCEWEBCAMCONTRASTCURRENT', $webcamcurrent);
					$smarty->assign('CFGSOURCEWEBCAMCONTRASTDEFAULT', $webcamdefault);
					$smarty->assign('CFGSOURCEWEBCAMCONTRASTCOMMENT', $webcamcomment);		
				}
				if (stripos($ligne, $witoget . "color") !== false) {
					list($webcamattribute, $webcamtype, $webcamcurrent, $webcamdefault, $webcamcomment) = explode("|", $ligne);
					$smarty->assign('CFGSOURCEWEBCAMCOLORATTRIBUTE', $webcamattribute);
					$smarty->assign('CFGSOURCEWEBCAMCOLORCURRENT', $webcamcurrent);
					$smarty->assign('CFGSOURCEWEBCAMCOLORDEFAULT', $webcamdefault);
					$smarty->assign('CFGSOURCEWEBCAMCOLORCOMMENT', $webcamcomment);		
				}
				if (stripos($ligne, $witoget . "hue") !== false) {
					list($webcamattribute, $webcamtype, $webcamcurrent, $webcamdefault, $webcamcomment) = explode("|", $ligne);
					$smarty->assign('CFGSOURCEWEBCAMHUEATTRIBUTE', $webcamattribute);
					$smarty->assign('CFGSOURCEWEBCAMHUECURRENT', $webcamcurrent);
					$smarty->assign('CFGSOURCEWEBCAMHUEDEFAULT', $webcamdefault);
					$smarty->assign('CFGSOURCEWEBCAMHUECOMMENT', $webcamcomment);		
				}					
				//if (!feof($fd)) echo "Ligne $i : ".htmlEntities($ligne)."<br/>";
				$i++;
			}
			fclose($fd);
		}
		if ($webcamboxconfig["cfgsourcetype"] == "gphoto") {
			//Gphoto2 Ports
			//gphoto2 --auto-detect |egrep -o "usb:...,..."
			passthru("sudo -u " . $config_systemuser . " /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " gphoto2usbports");
			if (is_file("/tmp/gphoto2ports")) {
				$fd = @fopen("/tmp/gphoto2ports","r");	
				$cptports=0;
	   		while (!feof($fd)) {	
					$ligne = fgets($fd, 1024);
		      	if (!feof($fd)) {
		      		if ($ligne != "") {
		        			$gphotoports[$cptports] = trim($ligne);
		        			$cptports++;
		        		}
		         }
				}
				fclose($fd);
				$smarty->assign('CPTGPHOTOPORTS', $cptports);
				$smarty->assign('GPHOTOPORTS', $gphotoports);					
			}  		
			//$searchgphotoports = file_get_contents("/tmp/gphoto2ports");
			//echo "<pre>$searchgphotoports</pre>";
			//$smarty->assign('DISPGPHOTOPORTS', $searchgphotoports);
		}

if (is_file($config_directory . "include/languages/" . $config_lang . "/config-source.php")) {
	include($config_directory . "include/languages/" . $config_lang . "/config-source.php");
}
$smarty->assign('LOCALE_HELP', $config_directory . 'include/languages/' . $config_lang . '/pages/' . 'locale.help.tpl');
$smarty->assign('CONFIGPAGE', 'source');
$smarty->assign('CENTRAL', 'config-source.tpl');
$smarty->display('skeleton.tpl');
?>