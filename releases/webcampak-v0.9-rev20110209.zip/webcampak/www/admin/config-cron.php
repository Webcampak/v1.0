<?php
// Copyright 2010 Infracom & Eurotechnia (support@webcampak.com)
// This file is part of the Webcampak project.
// Webcampak is free software: you can redistribute it and/or modify it 
// under the terms of the GNU General Public License as published by 
// the Free Software Foundation, either version 3 of the License, 
// or (at your option) any later version.

// Webcampak is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
// even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.

// You should have received a copy of the GNU General Public License along with Webcampak. 
// If not, see http://www.gnu.org/licenses/.


require("../../etc/config.php");
$infradmin = "Y";
$smarty->assign('INFRADMIN', $infradmin);

		/*if (strip_tags($_GET['submit']) == "1") {
		   if (strip_tags($_POST['cfggphotoports']) == "yes") {
				wito_setconfig($config_etcdirectory . "config-general.cfg", "cfggphotoports", "yes");	
			} else {
				wito_setconfig($config_etcdirectory . "config-general.cfg", "cfggphotoports", "no");
			}
			wito_setconfig($config_etcdirectory . "config-general.cfg", "cfggphotoportscameras", strip_tags($_POST['cfggphotoportscameras']));										
			//wito_setconfig($config_etcdirectory . "config-general.cfg", "cfgftpresourcespassword", strip_tags($_POST['cfgftpresourcespassword']));											
		}*/
		
		for ($i=1;$i<$config_nbsources;$i++) {
			if (strip_tags($_GET['submit']) == "1") {			
				if (strip_tags($_POST['croncapturevalue' . $i]) != "") {
					wito_setconfig($config_etcdirectory . "config-source" . $i . ".cfg", "cfgcroncapturevalue", strip_tags($_POST['croncapturevalue' . $i]));														
				}
				if (strip_tags($_POST['croncaptureinterval' . $i]) != "") {
					wito_setconfig($config_etcdirectory . "config-source" . $i . ".cfg", "cfgcroncaptureinterval", strip_tags($_POST['croncaptureinterval' . $i]));														
				}
				if (strip_tags($_POST['croncapturehourall' . $i]) != "") {
					wito_setconfig($config_etcdirectory . "config-source" . $i . ".cfg", "cfgcroncapturehourall", strip_tags($_POST['croncapturehourall' . $i]));														
				} else {
					wito_setconfig($config_etcdirectory . "config-source" . $i . ".cfg", "cfgcroncapturehourall", "no");																		
				}
				if (strip_tags($_POST['croncapturehourstart' . $i]) != "") {
					wito_setconfig($config_etcdirectory . "config-source" . $i . ".cfg", "cfgcroncapturehourstart", strip_tags($_POST['croncapturehourstart' . $i]));														
				}
				if (strip_tags($_POST['croncapturehourstop' . $i]) != "") {
					wito_setconfig($config_etcdirectory . "config-source" . $i . ".cfg", "cfgcroncapturehourstop", strip_tags($_POST['croncapturehourstop' . $i]));														
				}
				if (strip_tags($_POST['croncapturedaysall' . $i]) != "") {
					wito_setconfig($config_etcdirectory . "config-source" . $i . ".cfg", "cfgcroncapturedaysall", strip_tags($_POST['croncapturedaysall' . $i]));														
				} else {
					wito_setconfig($config_etcdirectory . "config-source" . $i . ".cfg", "cfgcroncapturedaysall", "no");																		
				}
				if (strip_tags($_POST['croncapturedaysstart' . $i]) != "") {
					wito_setconfig($config_etcdirectory . "config-source" . $i . ".cfg", "cfgcroncapturedaysstart", strip_tags($_POST['croncapturedaysstart' . $i]));														
				}
				if (strip_tags($_POST['croncapturedaysstop' . $i]) != "") {
					wito_setconfig($config_etcdirectory . "config-source" . $i . ".cfg", "cfgcroncapturedaysstop", strip_tags($_POST['croncapturedaysstop' . $i]));														
				}				
				if (strip_tags($_POST['crondailyhour' . $i]) != "") {
					wito_setconfig($config_etcdirectory . "config-source" . $i . ".cfg", "cfgcrondailyhour", strip_tags($_POST['crondailyhour' . $i]));														
				}				
				if (strip_tags($_POST['crondailyminute' . $i]) != "") {
					wito_setconfig($config_etcdirectory . "config-source" . $i . ".cfg", "cfgcrondailyminute", strip_tags($_POST['crondailyminute' . $i]));														
				}				
				if (strip_tags($_POST['croncustomvalue' . $i]) != "") {
					wito_setconfig($config_etcdirectory . "config-source" . $i . ".cfg", "cfgcroncustomvalue", strip_tags($_POST['croncustomvalue' . $i]));														
				}				
				if (strip_tags($_POST['croncustominterval' . $i]) != "") {
					wito_setconfig($config_etcdirectory . "config-source" . $i . ".cfg", "cfgcroncustominterval", strip_tags($_POST['croncustominterval' . $i]));														
				}				
			}
			$webcampakconfig[$i] = wito_getfullconfig($config_etcdirectory . "config-source" . $i . ".cfg");
			//echo "CRON $i : " . $webcampakconfig[$i]["cfgcroncapturevalue"] . "<br />";
			$croncapturevalue[$i] = $webcampakconfig[$i]["cfgcroncapturevalue"];
			$croncaptureinterval[$i] = $webcampakconfig[$i]["cfgcroncaptureinterval"];
			$crondailyhour[$i] = $webcampakconfig[$i]["cfgcrondailyhour"];
			$crondailyminute[$i] = $webcampakconfig[$i]["cfgcrondailyminute"];
			$croncustomvalue[$i] = $webcampakconfig[$i]["cfgcroncustomvalue"];
			$croncustominterval[$i] = $webcampakconfig[$i]["cfgcroncustominterval"];
			if ($webcampakconfig[$i]["cfgcroncapturehourall"] == "yes") {
				$croncapturehourall[$i] = "checked";
			}
			$croncapturehourstart[$i] = $webcampakconfig[$i]["cfgcroncapturehourstart"];
			$croncapturehourstop[$i] = $webcampakconfig[$i]["cfgcroncapturehourstop"];
			if ($webcampakconfig[$i]["cfgcroncapturedaysall"] == "yes") {
				$croncapturedaysall[$i] = "checked";
			}
			$croncapturedaysstart[$i] = $webcampakconfig[$i]["cfgcroncapturedaysstart"];
			$croncapturedaysstop[$i] = $webcampakconfig[$i]["cfgcroncapturedaysstop"];
			
		}
		$smarty->assign('CRONCAPTUREVALUE', $croncapturevalue);
		$smarty->assign('CRONCAPTUREINTERVAL', $croncaptureinterval);
		$smarty->assign('CRONCAPTUREHOURALL', $croncapturehourall);
		$smarty->assign('CRONCAPTUREHOURSTART', $croncapturehourstart);
		$smarty->assign('CRONCAPTUREHOURSTOP', $croncapturehourstop);
		$smarty->assign('CRONCAPTUREDAYSALL', $croncapturedaysall);
		$smarty->assign('CRONCAPTUREDAYSSTART', $croncapturedaysstart);
		$smarty->assign('CRONCAPTUREDAYSSTOP', $croncapturedaysstop);
		$smarty->assign('CRONDAILYHOUR', $crondailyhour);
		$smarty->assign('CRONDAILYMINUTE', $crondailyminute);
		$smarty->assign('CRONCUSTOMVALUE', $croncustomvalue);
		$smarty->assign('CRONCUSTOMINTERVAL', $croncustominterval);		
		$smarty->assign('CRONNBSOURCES', $config_nbsources);	
			
		//$webcamboxconfig = wito_getfullconfig($config_etcdirectory . "config-general.cfg");
		if (strip_tags($_GET['submit']) == "1") {	
			passthru("sudo -u " . $config_systemuser . " /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " updatecron");
		}	 

if (is_file($config_directory . "include/languages/" . $config_lang . "/config-cron.php")) {
	include($config_directory . "include/languages/" . $config_lang . "/config-cron.php");
}

$smarty->assign('LOCALE_HELP', $config_directory . 'include/languages/' . $config_lang . '/pages/' . 'locale.help.tpl');
$smarty->assign('CONFIGSYSTEM', '1');
$smarty->assign('CONFIGPAGE', 'cron');
$smarty->assign('CONFIGSOURCE', '0');
$smarty->assign('CENTRAL', 'config-cron.tpl');
$smarty->display('skeleton.tpl');

?>