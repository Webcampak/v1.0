<?php 
//<!--{$LANG_LOGS_SOURCE}-->
$smarty->assign('LANG_LOGS_SOURCE', "Source");
$smarty->assign('LANG_LOGS_TITLE', ": Affichage des Logs");
$smarty->assign('LANG_LOGS_TIP', "Astuce:");

$smarty->assign('LANG_LOGS_DEBUG', "Débug prolongé");
$smarty->assign('LANG_LOGS_DEBUGACTIVATE', "Activer debug prolongé:");
$smarty->assign('LANG_LOGS_DEBUGBUTTON', "Enregistrer");
$smarty->assign('LANG_LOGS_DEBUGTIP', "Par défaut les logs précédents sont effacés à chaque nouvelle execution du cache, cette option permet de conserver les anciens logs indéfiniment.");

$smarty->assign('LANG_LOGS_PICTURES', "Logs Photos");
$smarty->assign('LANG_LOGS_DAILYVID', "Logs Vidéo Journalière");
$smarty->assign('LANG_LOGS_CUSTOMVID', "Logs Vidéo Personnalisée");


?>