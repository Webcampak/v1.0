<?php 
//<!--{$LANG_WEBMIN_DESCRIPTION}-->

$smarty->assign('LANG_WEBMIN_TITLE', "Administration du système");
$smarty->assign('LANG_WEBMIN_DESCRIPTION', "L'outil Webmin vous permet de modifier les paramètres du système ainsi que l'intervalle entre les captures.<br/>");







?>