<?php 
//<!--{$LANG_MANAGEVIDEOS_SOURCE}-->
$smarty->assign('LANG_MANAGEVIDEOS_SOURCE', "Source");
$smarty->assign('LANG_MANAGEVIDEOS_TITLE', ": Vidéos Archivées");
$smarty->assign('LANG_MANAGEVIDEOS_TIP', "Astuce:");

$smarty->assign('LANG_MANAGEVIDEOS_MANAGE', "Gestion des vidéos archivées");
$smarty->assign('LANG_MANAGEVIDEOS_DATE', "Date");
$smarty->assign('LANG_MANAGEVIDEOS_BUTTON', "Suppr.");

?>