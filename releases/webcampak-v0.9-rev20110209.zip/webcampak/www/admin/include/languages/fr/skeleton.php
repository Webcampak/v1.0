<?php 
//<!--{$LANG_SKELETON_INDEX_ADMINLINK}-->
$smarty->assign('LANG_SKELETON_INDEX_ADMINLINK', "Index interface d'administration");
$smarty->assign('LANG_SKELETON_INDEX_ADMINTITLE', "Administration");
$smarty->assign('LANG_SKELETON_REMAININGDISKSPACE', "Espace disque restant:");

$smarty->assign('LANG_SKELETON_CONNECTEDCAMERAS', "Appareils Connectés");
$smarty->assign('LANG_SKELETON_ADMINSOURCE', "Admin. Source");

$smarty->assign('LANG_SKELETON_SYSTEMMENU_TITLE', "Système");
$smarty->assign('LANG_SKELETON_SYSTEMMENU_CRON', "Planification");
$smarty->assign('LANG_SKELETON_SYSTEMMENU_CONNECTEDCAMERAS', "Appareils Connectés");
$smarty->assign('LANG_SKELETON_SYSTEMMENU_WEBMIN', "Webmin");
$smarty->assign('LANG_SKELETON_SYSTEMMENU_REBOOT', "Reboot");
$smarty->assign('LANG_SKELETON_SYSTEMMENU_SYSTEMLOGS', "Logs Système");
$smarty->assign('LANG_SKELETON_SYSTEMMENU_RESET', "Reset");

$smarty->assign('LANG_SKELETON_SOURCEMENU_TITLE', "Source");
$smarty->assign('LANG_SKELETON_SOURCEMENU_CAPTURE', "Capture");
$smarty->assign('LANG_SKELETON_SOURCEMENU_PHOTOS', "Photos");
$smarty->assign('LANG_SKELETON_SOURCEMENU_VIDEOS', "Vidéos");
$smarty->assign('LANG_SKELETON_SOURCEMENU_CUSTOMVIDEOS', "Vidéos Perso.");
$smarty->assign('LANG_SKELETON_SOURCEMENU_FTP', "FTP");
$smarty->assign('LANG_SKELETON_SOURCEMENU_LOGS', "Logs");
$smarty->assign('LANG_SKELETON_SOURCEMENU_MOTION', "Détection Mouvements");
$smarty->assign('LANG_SKELETON_SOURCEMENU_ADVANCED', "Avancé");
$smarty->assign('LANG_SKELETON_SOURCEMENU_MANAGEPICTURES', "Gérer Archives Photos");
$smarty->assign('LANG_SKELETON_SOURCEMENU_MANAGEVIDEOS', "Gérer Archives Vidéos");
$smarty->assign('LANG_SKELETON_SOURCEMENU_VIEWARCHIVES', "Voir Archives Photos");

$smarty->assign('LANG_SKELETON_EXITMENU_TITLE', "Quitter");
$smarty->assign('LANG_SKELETON_EXITMENU_VIEWER', "Interface Visiteur");

$smarty->assign('LANG_SKELETON_HELP', "Aide");
$smarty->assign('LANG_SKELETON_ABOUT', "A Propos");

$smarty->assign('LANG_SKELETON_FOOTER', "Solution développée et mise en oeuvre par <a href='http://online.infracom-france.com/' class='redlnk'>Infracom</a> 
        (<a href='http://online.infracom-france.com/' class='redlnk'>Boutique</a>       
        | 
        <a href='http://blog.infracom.fr/' class='redlnk'>Blog</a>) et <a href='http://www.eurotechnia.fr/' class='redlnk'>Eurotechnia</a> - Interface d'administration basée sur le thème <a href='http://www.wordpress-fr.net/'>WordPress</a>.");

$smarty->assign('LANG_SKELETON_FOOTER_VERSION', "Version");

?>