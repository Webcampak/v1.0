<?php 
//<!--{$LANG_SYSTEMLOGS_TITLE}-->

$smarty->assign('LANG_SYSTEMLOGS_TITLE', "Logs Système");
$smarty->assign('LANG_SYSTEMLOGS_TIP', "Actions lancées par l'utilisateur depuis l'interface web");



?>