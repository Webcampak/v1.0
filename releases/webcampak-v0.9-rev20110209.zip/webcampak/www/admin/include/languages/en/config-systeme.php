<?php 
//<!--{$LANG_SYSTEME_TITLE}-->

$smarty->assign('LANG_SYSTEME_TITLE', "System Configuration");
$smarty->assign('LANG_SYSTEME_TIP', "Tip:");

$smarty->assign('LANG_SYSTEME_PRESENTATION_TITLE', "Presentation");
$smarty->assign('LANG_SYSTEME_PRESENTATION_TITLEDESCRIPTION', "You are currently connected to the administration panel of your Webcampak.<br />You can use menus on the left to navigate through the system.");

$smarty->assign('LANG_SYSTEME_ASSISTANCE_TITLE', "Remote Help");
$smarty->assign('LANG_SYSTEME_ASSISTANCE_STATUS', "VPN client status:");
$smarty->assign('LANG_SYSTEME_ASSISTANCE_START', "Start remote control");
$smarty->assign('LANG_SYSTEME_ASSISTANCE_STOP', "Stop remote control");
$smarty->assign('LANG_SYSTEME_ASSISTANCE_TIP', "Remote control/help is a VPN tunnel established between your webcampak and Infracom offices, we can then connect to your webcampak through this secured tunnel.");

$smarty->assign('LANG_SYSTEME_MULTI_TITLE', "Multi-Cameras Compacts and DSLR (Advanced)");
$smarty->assign('LANG_SYSTEME_MULTI_AUTODETECT', "Activate USB port auto-detect:");
$smarty->assign('LANG_SYSTEME_MULTI_TYPES', "Camera Model:");
$smarty->assign('LANG_SYSTEME_MULTI_CURRENT', "Currently: ");
$smarty->assign('LANG_SYSTEME_MULTI_DIFFERENT', "Different models");
$smarty->assign('LANG_SYSTEME_MULTI_IDENTICAL', "Identical models");
$smarty->assign('LANG_SYSTEME_MULTI_BUTTON', "Save");
$smarty->assign('LANG_SYSTEME_MULTI_TIP', "This is only useful when multiple USB Compacts/DSLR cameras are used.");

$smarty->assign('LANG_SYSTEME_FTP_TITLE', "FTP Access to resources directory");
$smarty->assign('LANG_SYSTEME_FTP_USERNAME', "Username:");
$smarty->assign('LANG_SYSTEME_FTP_PASSWORD', "Password:");
$smarty->assign('LANG_SYSTEME_FTP_BUTTON', "Create/Edit user");
$smarty->assign('LANG_SYSTEME_FTP_TIP', "Those credentials are used to access resources directory. Logs, Audio files, Watermarks are located in this directory.");


$smarty->assign('LANG_SYSTEME_GPHOTO_TITLE', "Gphoto2 Version");
$smarty->assign('LANG_SYSTEME_UPTIME_TITLE', "Uptime & Disk");
$smarty->assign('LANG_SYSTEME_PS_TITLE', "System Processes (ps aux)");

?>