<?php 
//<!--{$LANG_CONFIGDEBUT_TITLE}-->
$smarty->assign('LANG_CONFIGDEBUT_TITLE', "Configuration file - Source ");
$smarty->assign('LANG_CONFIGDEBUT_CONFIGURATION', "Configuration");




?>