<?php 
//<!--{$LANG_RESET_TITLE}-->
$smarty->assign('LANG_RESET_TITLE', "Reset System");
$smarty->assign('LANG_RESET_ALLSOURCES', "Reset all sources:");
$smarty->assign('LANG_RESET_ALLSOURCESTXT', "Reset configuration of all sources:");
$smarty->assign('LANG_RESET_ALLSOURCESBUTTON', "Reset configuration from all sources");
$smarty->assign('LANG_RESET_ALLCONTENT', "Delete all pictures and videos:");
$smarty->assign('LANG_RESET_ALLCONTENTBUTTON', "Delete all pictures and videos");
$smarty->assign('LANG_RESET_WARNING', "<strong><font color='red'>Warning:</strong> actions are definitive</font><br/><br/>If you want to make changes on a single source please visit 'advanced' section of the appropriate source.");



?>