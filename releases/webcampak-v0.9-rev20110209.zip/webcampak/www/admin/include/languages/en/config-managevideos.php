<?php 
//<!--{$LANG_MANAGEVIDEOS_SOURCE}-->
$smarty->assign('LANG_MANAGEVIDEOS_SOURCE', "Source");
$smarty->assign('LANG_MANAGEVIDEOS_TITLE', ": Saved Videos");
$smarty->assign('LANG_MANAGEVIDEOS_TIP', "Tip:");

$smarty->assign('LANG_MANAGEVIDEOS_MANAGE', "Manage saved videos");
$smarty->assign('LANG_MANAGEVIDEOS_DATE', "Date");
$smarty->assign('LANG_MANAGEVIDEOS_BUTTON', "Del.");

?>