<?php 
//<!--{$LANG_VIDEOS_SOURCE}-->

$smarty->assign('LANG_VIDEOS_SOURCE', "Source");
$smarty->assign('LANG_VIDEOS_TITLE', ": Video configuration");
$smarty->assign('LANG_VIDEOS_TIP', "Tip:");

$smarty->assign('LANG_VIDEOS_DAILY_TITLE', "Daily video creation");
$smarty->assign('LANG_VIDEOS_DAILY_FORMAT', "Format");
$smarty->assign('LANG_VIDEOS_DAILY_WEB', "Web<br />(MP4)");
$smarty->assign('LANG_VIDEOS_DAILY_DESCRIPTION', "Description");
$smarty->assign('LANG_VIDEOS_DAILY_EFFECT', "Visual Effect*<br /><i>Test only</i>");
$smarty->assign('LANG_VIDEOS_DAILY_MINSIZE', "Min. size <br /><i>(KB)</i>");
$smarty->assign('LANG_VIDEOS_DAILY_SPEED', "Creation<br /><i>Speed</i>");
$smarty->assign('LANG_VIDEOS_DAILY_HD', "- Hight Definition (HD) - H.264:");
$smarty->assign('LANG_VIDEOS_DAILY_HDMAX', "HD Format, Highest quality.");
$smarty->assign('LANG_VIDEOS_DAILY_HDGOOD', "HD Format, High quality.");
$smarty->assign('LANG_VIDEOS_DAILY_SD', "- Standard Definition:");
$smarty->assign('LANG_VIDEOS_DAILY_SDDVD', "Similar to DVD.");
$smarty->assign('LANG_VIDEOS_DAILY_CUSTOM', "H. 264 (Custom):");
$smarty->assign('LANG_VIDEOS_DAILY_CUSTOMTXT', "H.264, customisable parameters.");
$smarty->assign('LANG_VIDEOS_DAILY_NO', "No");
$smarty->assign('LANG_VIDEOS_DAILY_WARNING', "<strong><span class='blue'>Warning:</span></strong><br /> - *Visual effect is only available for testing purposes, may be unstable and use a large amount of CPU/Memory. Creation time will be at least multiplied by two.");

$smarty->assign('LANG_VIDEOS_ADVANCED_TITLE', "Advanced Parameters - Video Compression");
$smarty->assign('LANG_VIDEOS_ADVANCED_FORMAT', "Format");
$smarty->assign('LANG_VIDEOS_ADVANCED_FPS', "FPS");
$smarty->assign('LANG_VIDEOS_ADVANCED_BITRATE', "Bitrate");
$smarty->assign('LANG_VIDEOS_ADVANCED_RESOLUTION', "Resolution");
$smarty->assign('LANG_VIDEOS_ADVANCED_CUT', "Cropping");
$smarty->assign('LANG_VIDEOS_ADVANCED_PASSES', "2 Passes");
$smarty->assign('LANG_VIDEOS_ADVANCED_HD', "- Hight Definition (HD) - H.264:");
$smarty->assign('LANG_VIDEOS_ADVANCED_SD', "- Standard Definition:");
$smarty->assign('LANG_VIDEOS_ADVANCED_CUSTOM', "H. 264 (Custom):");

$smarty->assign('LANG_VIDEOS_PREPROCESS_TITLE', "Advanced Parameters - Pre-processing manipulations");
$smarty->assign('LANG_VIDEOS_PREPROCESS_TEXT', "Those options allow you to modify pictures before video creation. You can use it do add an additional legend, resize pictures ... Be careful those options will increase time necessary to create videos.<br />");
$smarty->assign('LANG_VIDEOS_PREPROCESS_LEGEND', "Legend");
$smarty->assign('LANG_VIDEOS_PREPROCESS_LEGENDTXT', "Insert a legend in the picture:");
$smarty->assign('LANG_VIDEOS_PREPROCESS_LEGENDVALUE', "Legend:");
$smarty->assign('LANG_VIDEOS_PREPROCESS_FORMAT', "Date format:");
$smarty->assign('LANG_VIDEOS_PREPROCESS_NODATE', "No date");
$smarty->assign('LANG_VIDEOS_PREPROCESS_FORMAT4', "Thursday 25 January 2010 - 09h30");
$smarty->assign('LANG_VIDEOS_PREPROCESS_FORMAT5', "25 January 2010 - 09h30");
$smarty->assign('LANG_VIDEOS_PREPROCESS_ADVANCED', "Advanced text configuration:");
$smarty->assign('LANG_VIDEOS_PREPROCESS_FONTSIZE', "Font size:");
$smarty->assign('LANG_VIDEOS_PREPROCESS_FONTLOCATION', "Text location:");
$smarty->assign('LANG_VIDEOS_PREPROCESS_FONTSOUTHWEST', "Down left (southwest)");
$smarty->assign('LANG_VIDEOS_PREPROCESS_FONTSOUTH', "Down middle (south)");
$smarty->assign('LANG_VIDEOS_PREPROCESS_FONTSOUTHEAST', "Down right (southeast)");
$smarty->assign('LANG_VIDEOS_PREPROCESS_FONTEAST', "Middle right (east)");
$smarty->assign('LANG_VIDEOS_PREPROCESS_FONTNORTHEAST', "Top right (northeast)");
$smarty->assign('LANG_VIDEOS_PREPROCESS_FONTNORTH', "Top middle (north)");
$smarty->assign('LANG_VIDEOS_PREPROCESS_FONTNORTWEST', "Top left (northwest)");
$smarty->assign('LANG_VIDEOS_PREPROCESS_FONTWEST', "Middle left (west)");
$smarty->assign('LANG_VIDEOS_PREPROCESS_FONTNAME', "Font:");
$smarty->assign('LANG_VIDEOS_PREPROCESS_FONTSHADOWCOLOR', "Shadow color:");
$smarty->assign('LANG_VIDEOS_PREPROCESS_FONTSHADOWCOORDINATES', "Shadow coordinates:");
$smarty->assign('LANG_VIDEOS_PREPROCESS_FONTCOLOR', "Font color:");
$smarty->assign('LANG_VIDEOS_PREPROCESS_FONTCOORDINATES', "Text coordinates:");

$smarty->assign('LANG_VIDEOS_PREPROCESS_RESIZE', "Resize");
$smarty->assign('LANG_VIDEOS_PREPROCESS_RESIZETXT', "Resize picture before video creation:");
$smarty->assign('LANG_VIDEOS_PREPROCESS_RESIZETXTVALUE', "New size (for example: 2272x1704):");
$smarty->assign('LANG_VIDEOS_PREPROCESS_TIP', "This functionality might be useful if your camera takes very large pictures.");

$smarty->assign('LANG_VIDEOS_AUDIO_TITLE', "Audio track");
$smarty->assign('LANG_VIDEOS_AUDIO_ADDTRACK', "Add an audio track:");
$smarty->assign('LANG_VIDEOS_AUDIO_AUDIOFILE', "Audio file:");
$smarty->assign('LANG_VIDEOS_AUDIO_TIP', "Audio files must be uploaded via FTP to /audio/ directory available via the global ftp account (see 'System').<br /><strong>Warning:</strong> Filename must not contain any spaces or special characters.");

$smarty->assign('LANG_VIDEOS_WATERMARK_TITLE', "Insert Watermark (image on top of a picture)");
$smarty->assign('LANG_VIDEOS_WATERMARK_ACTIVATE', "Insert a watermark into the picture:");
$smarty->assign('LANG_VIDEOS_WATERMARK_SOURCE', "Watermark file:");
$smarty->assign('LANG_VIDEOS_WATERMARK_TRANSPARENCY', "Transparancy:");
$smarty->assign('LANG_VIDEOS_WATERMARK_XCOORDINATE', "Horizontale coordinate (X):");
$smarty->assign('LANG_VIDEOS_WATERMARK_YCOORDINATE', "Verticale coordinate (Y):");
$smarty->assign('LANG_VIDEOS_WATERMARK_TIP', "Watermark files must be using 'PNG' format and be located within /watermark/ folder reachable via the FTP global account (via System tab), this folder is shared between all sources. <br />	Starting point for coordinates is to top left corner of the picture <br /> <strong>Warning:</strong> Filenames must not contain spaces of special characters.");


$smarty->assign('LANG_VIDEOS_YOUTUBE_TITLE', "Youtube Upload");
$smarty->assign('LANG_VIDEOS_YOUTUBE_ACTIVATE', "Activate Youtube upload:");
$smarty->assign('LANG_VIDEOS_YOUTUBE_CATEGORY', "Video Category:");
$smarty->assign('LANG_VIDEOS_YOUTUBE_TIP', "To upload a video to Youtube an authentication key must be linked to your account and stored within the webcampak. Key creation has been made in our office, you sould have been provided with instructions to link this key to your google account.<br /> Video with the best quality will be uploaded to Youtube.<br />");


$smarty->assign('LANG_VIDEOS_STATIC_TITLE', "Static Videos (hotlink)");
$smarty->assign('LANG_VIDEOS_STATIC_FILENAME', "Name of the last daily video file (no extension):");
$smarty->assign('LANG_VIDEOS_STATIC_CREATEVID', "Create a downloadable static video file:");
$smarty->assign('LANG_VIDEOS_STATIC_CREATEWEB', "Create an MP4 (Web) static video file:");
$smarty->assign('LANG_VIDEOS_STATIC_TIP', "A static picture or video is a file whome name is constantly the same, only the content changes. Those pictures can be use by a website displaying a webcam for example.");

$smarty->assign('LANG_VIDEOS_BUTTON', "Save");





?>