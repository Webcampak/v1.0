<?php 
//<!--{$LANG_CONFIGFTP_SOURCE}-->
$smarty->assign('LANG_CONFIGFTPCACHELOGS_TITLE', "Logs mise en cache FTP");
$smarty->assign('LANG_CONFIGFTPCACHELOGS_TIP', "Astuce:");

$smarty->assign('LANG_CONFIGFTPCACHELOGS_DEBUG', "Débug prolongé");
$smarty->assign('LANG_CONFIGFTPCACHELOGS_DEBUGACTIVATE', "Activer debug prolongé:");
$smarty->assign('LANG_CONFIGFTPCACHELOGS_DEBUGBUTTON', "Enregistrer");
$smarty->assign('LANG_CONFIGFTPCACHELOGS_DEBUGTIP', "Par défaut les logs précédents sont effacés à chaque nouvelle execution du cache, cette option permet de conserver les anciens logs indéfiniment.");

$smarty->assign('LANG_CONFIGFTPCACHELOGS_TIP', "Astuc");
$smarty->assign('LANG_CONFIGFTPCACHELOGS_TIP', "Astuc");

?>