<?php 
//<!--{$LANG_LOGS_SOURCE}-->
$smarty->assign('LANG_MANAGEPICTURES_SOURCE', "Source");
$smarty->assign('LANG_MANAGEPICTURES_TITLE', ": Saved Pictures");
$smarty->assign('LANG_MANAGEPICTURES_TIP', "Tip:");

$smarty->assign('LANG_MANAGEPICTURES_MANAGE', "Manage saved pictures");
$smarty->assign('LANG_MANAGEPICTURES_DATE', "Date");
$smarty->assign('LANG_MANAGEPICTURES_NBPICS', "Number");
$smarty->assign('LANG_MANAGEPICTURES_GLOBALSIZE', "Overall size");
$smarty->assign('LANG_MANAGEPICTURES_TOTAL', "TOTAL");
$smarty->assign('LANG_MANAGEPICTURES_TIPCONTENT', "Via this page you can easily delete a whole day of capture.<br />If you want to delete specific pictures, connect to Webcampak via FTP.");



?>