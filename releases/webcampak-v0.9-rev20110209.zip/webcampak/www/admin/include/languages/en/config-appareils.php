<?php 
//<!--{$LANG_CONFIGAPPAREILS_TITLE}-->
$smarty->assign('LANG_CONFIGAPPAREILS_TITLE', "Connected Devices");

$smarty->assign('LANG_CONFIGAPPAREILS_GPHOTOCONNECTED', "Digital PTP cameras (gphoto2)");
$smarty->assign('LANG_CONFIGAPPAREILS_GPHOTOCAPACITY', "Digital PTP cameras abilities (gphoto2)");
$smarty->assign('LANG_CONFIGAPPAREILS_USBDEVICES', "USB Devices (lsusb)");
$smarty->assign('LANG_CONFIGAPPAREILS_VIDEODEVICES', "Video devices, USB Webcams (/dev/video...)");
$smarty->assign('LANG_CONFIGAPPAREILS_VIDEODEVICES_ADVANCED', "Advanced - Video devices, USB Webcams (/dev/video...)");





?>