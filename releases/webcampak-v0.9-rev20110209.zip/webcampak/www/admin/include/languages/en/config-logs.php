<?php 
//<!--{$LANG_LOGS_SOURCE}-->
$smarty->assign('LANG_LOGS_SOURCE', "Source");
$smarty->assign('LANG_LOGS_TITLE', ": Logs");
$smarty->assign('LANG_LOGS_TIP', "Tip:");

$smarty->assign('LANG_LOGS_DEBUG', "Long lasting Debug");
$smarty->assign('LANG_LOGS_DEBUGACTIVATE', "Activation long lasting debug:");
$smarty->assign('LANG_LOGS_DEBUGBUTTON', "Save");
$smarty->assign('LANG_LOGS_DEBUGTIP', "Logs are deleted automaticall each time a new capture of video creation is started. This option let you record logs indefinitely.");

$smarty->assign('LANG_LOGS_PICTURES', "Logs Capture");
$smarty->assign('LANG_LOGS_DAILYVID', "Logs Daily Video");
$smarty->assign('LANG_LOGS_CUSTOMVID', "Logs Custom Video");


?>