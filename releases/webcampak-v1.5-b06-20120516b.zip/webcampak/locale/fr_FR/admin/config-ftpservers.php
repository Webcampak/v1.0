<?php 
$smarty->assign('LANG_CONFIGFTPSERVERS_TITLE', "Configuration des serveurs FTP de destination");

$smarty->assign('LANG_CONFIGFTPSERVERS_LIST_TITLE', "Enregistrement des serveurs FTP");
$smarty->assign('LANG_CONFIGFTPSERVERS_LIST_ID', "#");
$smarty->assign('LANG_CONFIGFTPSERVERS_LIST_NAME', "Désignation");
$smarty->assign('LANG_CONFIGFTPSERVERS_LIST_HOST', "Host");
$smarty->assign('LANG_CONFIGFTPSERVERS_LIST_USERNAME', "Username");
$smarty->assign('LANG_CONFIGFTPSERVERS_LIST_PASSWORD', "Password");
$smarty->assign('LANG_CONFIGFTPSERVERS_LIST_DIRECTORY', "Répertoire");
$smarty->assign('LANG_CONFIGFTPSERVERS_LIST_ACTIVE', "Mode Actif");
$smarty->assign('LANG_CONFIGFTPSERVERS_LIST_BUTTON', "Enregistrer");

?>
