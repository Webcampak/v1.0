<?php 
$smarty->assign('LANG_SKELETON_INDEX_ADMINLINK', "Index administration panel");
$smarty->assign('LANG_SKELETON_INDEX_ADMINTITLE', "Administration panel");
$smarty->assign('LANG_SKELETON_REMAININGDISKSPACE', "Free disk space:");

$smarty->assign('LANG_SKELETON_CONNECTEDCAMERAS', "Connected Devices");
$smarty->assign('LANG_SKELETON_ADMINSOURCE', "Source Admin");

$smarty->assign('LANG_SKELETON_SYSTEMMENU_TITLE', "System");
$smarty->assign('LANG_SKELETON_SYSTEMMENU_CRON', "Scheduler");
$smarty->assign('LANG_SKELETON_SYSTEMMENU_CONNECTEDCAMERAS', "Connected Devices");
$smarty->assign('LANG_SKELETON_SYSTEMMENU_WEBMIN', "Webmin");
$smarty->assign('LANG_SKELETON_SYSTEMMENU_REBOOT', "Reboot");
$smarty->assign('LANG_SKELETON_SYSTEMMENU_SYSTEMLOGS', "System Logs");
$smarty->assign('LANG_SKELETON_SYSTEMMENU_RESET', "Reset");

$smarty->assign('LANG_SKELETON_SOURCEMENU_TITLE', "Source");
$smarty->assign('LANG_SKELETON_SOURCEMENU_CAPTURE', "Capture");
$smarty->assign('LANG_SKELETON_SOURCEMENU_PHOTOS', "Photos");
$smarty->assign('LANG_SKELETON_SOURCEMENU_VIDEOS', "Videos");
$smarty->assign('LANG_SKELETON_SOURCEMENU_CUSTOMVIDEOS', "Custom Vids.");
$smarty->assign('LANG_SKELETON_SOURCEMENU_FTP', "FTP");
$smarty->assign('LANG_SKELETON_SOURCEMENU_LOGS', "Logs");
$smarty->assign('LANG_SKELETON_SOURCEMENU_MOTION', "Motion Detection");
$smarty->assign('LANG_SKELETON_SOURCEMENU_ADVANCED', "Advanced");
$smarty->assign('LANG_SKELETON_SOURCEMENU_MANAGEPICTURES', "Manage Pictures");
$smarty->assign('LANG_SKELETON_SOURCEMENU_MANAGEVIDEOS', "Manage Videos");
$smarty->assign('LANG_SKELETON_SOURCEMENU_VIEWARCHIVES', "Browse Pictures");

$smarty->assign('LANG_SKELETON_EXITMENU_TITLE', "Exit");
$smarty->assign('LANG_SKELETON_EXITMENU_VIEWER', "Viewer Interface");

$smarty->assign('LANG_SKELETON_HELP', "Help");
$smarty->assign('LANG_SKELETON_ABOUT', "About");

$smarty->assign('LANG_SKELETON_FOOTER', "Solution implemented by <a href='http://online.infracom-france.com/' class='redlnk'>Infracom</a> 
        (<a href='http://online.infracom-france.com/' class='redlnk'>Shop</a>       
        | 
        <a href='http://blog.infracom.fr/' class='redlnk'>Blog</a>) and <a href='http://www.eurotechnia.fr/' class='redlnk'>Eurotechnia</a> - Admin. Panel theme based upon <a href='http://www.wordpress-fr.net/'>WordPress</a> theme.");

$smarty->assign('LANG_SKELETON_FOOTER_VERSION', "Revision");

?>