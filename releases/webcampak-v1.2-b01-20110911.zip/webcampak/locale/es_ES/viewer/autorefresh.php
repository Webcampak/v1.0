<?php 
//<!--{$LANG_AUTOREFRESH_NOPICTURE}-->
$smarty->assign('LANG_AUTOREFRESH_NOPICTURE', "Fotografía no disponible, por favor seleccione otro tamaño o actualice la página.");

 
?>