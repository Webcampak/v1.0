<?php 
$smarty->assign('LANG_REBOOT_TITLE', "Redémarrage du système");
$smarty->assign('LANG_REBOOT_REBOOT', "Reboot");
$smarty->assign('LANG_REBOOT_AREYOUSURE', "Etes-vous sûrs de vouloir redémarrer le webcampak ?");
$smarty->assign('LANG_REBOOT_NOW', "(Redémarrer maintenant)");



?>