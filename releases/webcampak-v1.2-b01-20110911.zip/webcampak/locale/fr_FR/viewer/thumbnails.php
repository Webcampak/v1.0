<?php 
//<!--{$LANG_THUMBNAILS_NOPICTURE}-->
$smarty->assign('LANG_THUMBNAILS_SOURCE', "Source:");
$smarty->assign('LANG_THUMBNAILS_AVAILABLESIZES', "Résolutions disponibles:");
$smarty->assign('LANG_THUMBNAILS_NOPICTURE', "Aucun cliché actuellement disponible");

?>