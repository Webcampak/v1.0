<?php 
//<!--{$LANG_AUTOREFRESH_NOPICTURE}-->
$smarty->assign('LANG_AUTOREFRESH_NOPICTURE', "Picture not available, please select another size or refresh page.");
$smarty->assign('LANG_AUTOREFRESH_FULLSCREEN', "Display Fullscreen");



?>
