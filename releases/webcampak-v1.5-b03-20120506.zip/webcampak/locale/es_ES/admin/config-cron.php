<?php 
$smarty->assign('LANG_CRON_TITLE', "Planificador de Webcampak");
$smarty->assign('LANG_CRON_TIP', "Consejos:");
$smarty->assign('LANG_CRON_TIPTEXT', "El intervalo mínimo entre capturas es de 20 segundos");
$smarty->assign('LANG_CRON_BUTTON', "Guardar");

$smarty->assign('LANG_CRON_SOURCE', "Fuente");
$smarty->assign('LANG_CRON_SOURCETITLE', "Capturar fuente");

$smarty->assign('LANG_CRON_SOURCE_STARTCAPTURE', "Comenzar la captura cada");
$smarty->assign('LANG_CRON_SOURCE_SECONDS', "Segundos");
$smarty->assign('LANG_CRON_SOURCE_MINUTES', "Minutos");
$smarty->assign('LANG_CRON_SOURCE_HOURS', "Horas");

$smarty->assign('LANG_CRON_SOURCE_DAILYVIDTITLE', "Videos diarios");
$smarty->assign('LANG_CRON_SOURCE_DAILYSTART', "Comenzar la creación diaria de video a las");
$smarty->assign('LANG_CRON_SOURCE_DAILYHOUR', "h");
$smarty->assign('LANG_CRON_SOURCE_DAILYDAYS', "todos los días.");

$smarty->assign('LANG_CRON_SOURCE_CUSTOMTITLE', "Videos personalizados");
$smarty->assign('LANG_CRON_SOURCE_CUSTOMSTART', "Iniciar la creación personalizada de video y post-prod. cada");

$smarty->assign('LANG_CRON_CAPTURE_FREQUENCY', "Frecuencia");
$smarty->assign('LANG_CRON_CAPTURE_TIME', "Horas");
$smarty->assign('LANG_CRON_CAPTURE_DAYS', "Días");
$smarty->assign('LANG_CRON_CAPTURE_ALL', "Todo");
$smarty->assign('LANG_CRON_CAPTURE_FROM', "Desde");
$smarty->assign('LANG_CRON_CAPTURE_TO', "A");
$smarty->assign('LANG_CRON_CAPTURE_FROMB', "Desde");
$smarty->assign('LANG_CRON_CAPTURE_TOB', "A");

$smarty->assign('LANG_CRON_SOURCE_MONDAY', "Lunes");
$smarty->assign('LANG_CRON_SOURCE_TUESDAY', "Martes");
$smarty->assign('LANG_CRON_SOURCE_WEDNESDAY', "Miércoles");
$smarty->assign('LANG_CRON_SOURCE_THURSDAY', "Jueves");
$smarty->assign('LANG_CRON_SOURCE_FRIDAY', "Viernes");
$smarty->assign('LANG_CRON_SOURCE_SATURDAY', "Sábado");
$smarty->assign('LANG_CRON_SOURCE_SUNDAY', "Domingo");
  

?>
