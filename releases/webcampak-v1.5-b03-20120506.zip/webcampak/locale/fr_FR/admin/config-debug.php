<?php 
$smarty->assign('LANG_CONFIGDEBUT_TITLE', "Fichier de configuration - Source ");
$smarty->assign('LANG_CONFIGDEBUT_CONFIGURATION', "Configuration");

?>