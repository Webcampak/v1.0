<?php 
$smarty->assign('LANG_CONFIGFTPSERVERS_TITLE', "Destination FTP servers configuration");

$smarty->assign('LANG_CONFIGFTPSERVERS_LIST_TITLE', "Pre-configuration of destination FTP servers");
$smarty->assign('LANG_CONFIGFTPSERVERS_LIST_ID', "#");
$smarty->assign('LANG_CONFIGFTPSERVERS_LIST_NAME', "Name");
$smarty->assign('LANG_CONFIGFTPSERVERS_LIST_HOST', "Host");
$smarty->assign('LANG_CONFIGFTPSERVERS_LIST_USERNAME', "Username");
$smarty->assign('LANG_CONFIGFTPSERVERS_LIST_PASSWORD', "Password");
$smarty->assign('LANG_CONFIGFTPSERVERS_LIST_DIRECTORY', "Target Directory");
$smarty->assign('LANG_CONFIGFTPSERVERS_LIST_ACTIVE', "Active mode");
$smarty->assign('LANG_CONFIGFTPSERVERS_LIST_BUTTON', "Save");

?>
