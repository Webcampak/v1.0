<?php 
//<!--{$LANG_VIDEOS_DAILYVID}-->
$smarty->assign('LANG_VIDEOS_DAILYVID', "Video(s) du jour:");
$smarty->assign('LANG_VIDEOS_DAILYCREATEDVID', "Video(s) crées ce jour:");
$smarty->assign('LANG_VIDEOS_DOWNLOADVID', "Tél. vidéo");


$smarty->assign('LANG_VIDEOS_NOPREVIEW', "Prévisualisation vidéo indisponible. <br />Cochez la case 'Web' dans l'interface d'administration.");
  					


?>