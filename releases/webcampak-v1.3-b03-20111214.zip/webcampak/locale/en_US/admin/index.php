<?php 
$smarty->assign('LANG_INDEX_TITLE', "Last pictures captured");
$smarty->assign('LANG_INDEX_SOURCE_TITLE', "Source");
$smarty->assign('LANG_INDEX_SOURCE_AVAILABLESIZES', "Available sizes: ");
$smarty->assign('LANG_INDEX_SOURCE_NOPICTURES', "No picture currently available");




?>