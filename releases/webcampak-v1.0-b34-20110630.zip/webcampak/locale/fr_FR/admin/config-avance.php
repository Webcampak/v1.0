<?php 
$smarty->assign('LANG_CONFIGAVANCE_SOURCE', "Source");
$smarty->assign('LANG_CONFIGAVANCE_TITLE', ": Configuration Avancée");

$smarty->assign('LANG_CONFIGAVANCE_CONFIGURATIONFILE_TITLE', "Fichier de configuration");
$smarty->assign('LANG_CONFIGAVANCE_CONFIGURATIONFILE_IMPORT', "Importer fichier configuration:");
$smarty->assign('LANG_CONFIGAVANCE_CONFIGURATIONFILE_BUTTON', "Envoyer");
$smarty->assign('LANG_CONFIGAVANCE_CONFIGURATIONFILE_UPLOADSUCCESS', "Remplacement du fichier de configuration réalisé.");
$smarty->assign('LANG_CONFIGAVANCE_CONFIGURATIONFILE_WARNING', "<strong><font color='red'>Attention:</font></strong> l'import de fichier de configuration écrasera la configuration actuelle.	<br/>");
$smarty->assign('LANG_CONFIGAVANCE_CONFIGURATIONFILE_BUTTONDOWNLOAD', "Télécharger le fichier de configuration");
$smarty->assign('LANG_CONFIGAVANCE_CONFIGURATIONFILE_BUTTONDISPLAY', "Afficher le fichier de configuration");

$smarty->assign('LANG_CONFIGAVANCE_EMAIL_TITLE', "Configuration alerting email");
$smarty->assign('LANG_CONFIGAVANCE_EMAIL_SENDTO', "Adresse email destinataire alerte:");
$smarty->assign('LANG_CONFIGAVANCE_EMAIL_SENDCOPYTO', "Envoyer une copie de l'alerte à (@ email):");
$smarty->assign('LANG_CONFIGAVANCE_EMAIL_EMAILSOURCE', "Source de l'email (@ email):");
$smarty->assign('LANG_CONFIGAVANCE_EMAIL_NBFAILURES', "Nombre d'échecs avant envoi:");
$smarty->assign('LANG_CONFIGAVANCE_EMAIL_SMTPSERVER', "Serveur SMTP:Port");
$smarty->assign('LANG_CONFIGAVANCE_EMAIL_SMTPTTLS', "SMTP Start TTLS:");
$smarty->assign('LANG_CONFIGAVANCE_EMAIL_SMTPAUTH', "SMTP Auth:");
$smarty->assign('LANG_CONFIGAVANCE_EMAIL_SMTPAUTHUSERNAME', "SMTP Auth Username:");
$smarty->assign('LANG_CONFIGAVANCE_EMAIL_SMTPAUTHPASSWORD', "SMTP Auth Password:");
$smarty->assign('LANG_CONFIGAVANCE_EMAIL_BUTTON', "Sauvegarder");

$smarty->assign('LANG_CONFIGAVANCE_PHIDGET_TITLE', "Configuration platine Phidget pour la source");
$smarty->assign('LANG_CONFIGAVANCE_ERROR_ACTIVATE', "Activer le redémarrage électrique");
$smarty->assign('LANG_CONFIGAVANCE_GRAPH_ACTIVATE', "Créer le graphique journalier");
$smarty->assign('LANG_CONFIGAVANCE_ERROR_NBERRORS', "Nombre d'erreurs de capture avant redémarrage:");
$smarty->assign('LANG_CONFIGAVANCE_ERROR_PORT', "Port sur lequel est connecté le relais:");
$smarty->assign('LANG_CONFIGAVANCE_PHIDGET_TEMPERATURE', "Port sur lequel est connecté la sonde de température:");
$smarty->assign('LANG_CONFIGAVANCE_PHIDGET_LIGHT', "Port sur lequel est connecté la sonde de luminosité:");
$smarty->assign('LANG_CONFIGAVANCE_ERROR_DISABLED', "Désactivé");

$smarty->assign('LANG_CONFIGAVANCE_INIT_TITLEINIT', "Réinitialiser (source ");
$smarty->assign('LANG_CONFIGAVANCE_INIT_TITLEEND', " uniquement):"); 
$smarty->assign('LANG_CONFIGAVANCE_INIT_INITSOURCE', "Réinitialiser la configuration pour la source ");
$smarty->assign('LANG_CONFIGAVANCE_INIT_INITSOURCEBUTTON', "Réinitialiser source "); 
$smarty->assign('LANG_CONFIGAVANCE_INIT_INITVIDEO', "Etes vous sur de vouloir effacer l'ensemble des photos et videos:"); 
$smarty->assign('LANG_CONFIGAVANCE_INIT_INITVIDEOBUTTON', "Effacer l'ensemble des images et vidéos source "); 
$smarty->assign('LANG_CONFIGAVANCE_INIT_WARNING', "<strong><font color='red'>Attention:</strong> toute action est définitive	</font><br/>"); 

$smarty->assign('LANG_CONFIGAVANCE_MOTION_TITLE', "Détection de mouvements (Expérimental)");
$smarty->assign('LANG_CONFIGAVANCE_MOTION_ACTIVATE', "Activer détection de mouvements");
$smarty->assign('LANG_CONFIGAVANCE_MOTION_ONLY', "Enregistrer uniquement les clichés liées à la détection de mouvements");
$smarty->assign('LANG_CONFIGAVANCE_MOTION_DEVICE', "Source Video");

$smarty->assign('LANG_CONFIGAVANCE_MOTION_DEVICEWIDTH', "Largeur source (pixel width)");
$smarty->assign('LANG_CONFIGAVANCE_MOTION_DEVICEHEIGHT', "Hauteur source (pixel height)");
$smarty->assign('LANG_CONFIGAVANCE_MOTION_THRESHOLD', "Seuil déclenchement (en pixels modifiés)");
$smarty->assign('LANG_CONFIGAVANCE_MOTION_ENDEVENT', "Nombre de secondes avant de considérer l'évenement comme clos");
$smarty->assign('LANG_CONFIGAVANCE_MOTION_BUTTON', "Sauvegarder");
$smarty->assign('LANG_CONFIGAVANCE_MOTION_TIP', "Attention:");
$smarty->assign('LANG_CONFIGAVANCE_MOTION_WARNING', "Cette fonctionalité a été prévue pour être utilisée avec une source de type appareil photo réflex. Une webcam sera utilisée conjointement comme détecteur de mouvement.");
$smarty->assign('LANG_CONFIGAVANCE_MOTION_INTERVAL', "Intervalle minimum:");
$smarty->assign('LANG_CONFIGAVANCE_MOTION_SECONDS', "Secondes");
$smarty->assign('LANG_CONFIGAVANCE_MOTION_MINUTES', "Minutes");


?>