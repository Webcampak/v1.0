<?php 
$smarty->assign('LANG_INDEX_TITLE', "Derniers clichés disponibles");
$smarty->assign('LANG_INDEX_SOURCE_TITLE', "Source");
$smarty->assign('LANG_INDEX_SOURCE_AVAILABLESIZES', "Résolutions disponibles: ");
$smarty->assign('LANG_INDEX_SOURCE_NOPICTURES', "Aucun cliché actuellement disponible");




?>