<?php 
//<!--{$LANG_PHOTOS_NOPICTURE}-->
$smarty->assign('LANG_PHOTOS_DOWNLOAD_PICTURE', "Tél. image");
$smarty->assign('LANG_PHOTOS_DOWNLOAD_ORIGINAL', "Tél. original");

$smarty->assign('LANG_PHOTOS_PREVIOUS', "Précédent");
$smarty->assign('LANG_PHOTOS_NEXT', "Suivant");

$smarty->assign('LANG_PHOTOS_NOPICTURE', "Image inexistante pour la date et l'heure sélectionnée.");


?>