<?php 
//<!--{$LANG_PHOTOS_NOPICTURE}-->
$smarty->assign('LANG_PHOTOS_DOWNLOAD_PICTURE', "Descargar fotografía");
$smarty->assign('LANG_PHOTOS_DOWNLOAD_ORIGINAL', "Descargar original");

$smarty->assign('LANG_PHOTOS_PREVIOUS', "Anterior");
$smarty->assign('LANG_PHOTOS_NEXT', "Siguiente");

$smarty->assign('LANG_PHOTOS_NOPICTURE', "No hay imagen disponible para la fecha y hora seleccionada.");
 

?>