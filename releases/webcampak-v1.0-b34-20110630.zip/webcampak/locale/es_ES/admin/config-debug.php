<?php 
$smarty->assign('LANG_CONFIGDEBUT_TITLE', "Configuración de archivo - Fuente ");
$smarty->assign('LANG_CONFIGDEBUT_CONFIGURATION', "Configuración");
 
?>