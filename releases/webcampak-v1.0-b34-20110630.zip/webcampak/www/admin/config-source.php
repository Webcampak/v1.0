<?php
// Copyright 2010 Infracom & Eurotechnia (support@webcampak.com)
// This file is part of the Webcampak project.
// Webcampak is free software: you can redistribute it and/or modify it 
// under the terms of the GNU General Public License as published by 
// the Free Software Foundation, either version 3 of the License, 
// or (at your option) any later version.

// Webcampak is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
// even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.

// You should have received a copy of the GNU General Public License along with Webcampak. 
// If not, see http://www.gnu.org/licenses/.


require("../../etc/admin.config.php");


$configsection = strip_tags($_GET['section']);
$smarty->assign('CONFIGSECTION', $configsection);

	//passthru('echo testee | sudo /usr/bin/php -f ' . $config_bindirectory . 'server.php'); 
	if (strip_tags($_GET['capture']) == "1") {
		//Lancer la capture de l'image
		passthru("sudo -u " . $config_systemuser . " /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " sample");
		$smarty->assign('DSIPLAYCAPTURE', '1' );
	}
	if (strip_tags($_GET['capturerecord']) == "1") {
		$currentdate = date("YmdHis");
		$currentday = date("Ymd");
		//Lancer la capture de l'image
		passthru("sudo -u " . $config_systemuser . " /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " samplerecord");
		$dirresultstmp = php4_scandir($config_campictures . $currentday);
		sort($dirresultstmp);
		for ($i=0;$i<sizeof($dirresultstmp);$i++) {
		    if (substr($dirresultstmp[$i], 0,14) >= $currentdate && substr($dirresultstmp[$i], 0,2) == "20") {
			$smarty->assign('PICTUREDISPLAY', $config_webcampictures . $currentday . "/" . $dirresultstmp[$i] );
		    }
		}
		//$smarty->assign('DSIPLAYCAPTURE', '1' );
	}	
	
	if (strip_tags($_GET['gphotoassign']) == "1") {
		passthru("sudo -u " . $config_systemuser . " /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " gphotoassign");
		$smarty->assign('GPHOTOASSIGNAPPLIED', '1' );
	}	
	
	$webcamboxconfig = wito_getfullconfig($config_witoconfig);
	$config_cambase = $webcamboxconfig["cfgbasedir"];
	$smarty->assign('WITODISKSPACE', wito_diskspace($config_base));
		//MODIFICATION DES PARAMETRES		
		if (strip_tags($_GET['submit']) == "1") {
			foreach ($_POST as $confkey=>$confvalue) {
				if (substr($confkey, 0, 3) == "cfg") {
					if ($confkey == "cfgsourcewebcamsize" && $confvalue == "autre") { $witoparameters[strip_tags($confkey)] = strip_tags($_POST['sourcewebcamsizeother']);}
					else {
						$witoparameters[strip_tags($confkey)] = strip_tags($confvalue);
					}
				}
			}
			if (strip_tags($_POST["cfgsourcedebug"]) == "") { $witoparameters["cfgsourcedebug"] = "no";}
			if (strip_tags($_POST["cfgemailerroractivate"]) == "") { $witoparameters["cfgemailerroractivate"] = "no";}
			if (strip_tags($_POST["cfgnocapture"]) == "") { $witoparameters["cfgnocapture"] = "no";}
			if (strip_tags($_POST["cfgsourcegphotocameramodel"]) == "") { $witoparameters["cfgsourcegphotocameramodel"] = "no";}
			if (strip_tags($_POST["cfgsourcegphotocalibration"]) == "") { $witoparameters["cfgsourcegphotocalibration"] = "no";}
			if (strip_tags($_POST["cfgsourcecamiplimiterotation"]) == "") { $witoparameters["cfgsourcecamiplimiterotation"] = "no";}
			if (strip_tags($_POST["cfgsourceactive"]) == "") { $witoparameters["cfgsourceactive"] = "no";}
			wito_writeconfig($config_witoconfig, $witoparameters);
		}
		//LECTURE DES PARAMETRES
		$webcamboxconfig = wito_getfullconfig($config_witoconfig);
		foreach ($webcamboxconfig as $readkey=>$readvalue) {
		      $smarty->assign(strtoupper($readkey), $readvalue);
		}
		if ($webcamboxconfig["cfgsourceactive"] == "yes") {
			$smarty->assign('CFGSOURCEACTIVE', "checked");
		}
		if ($webcamboxconfig["cfgsourcedebug"] == "yes") {
			$smarty->assign('CFGSOURCEDEBUG', "checked");
		}
		if ($webcamboxconfig["cfgemailerroractivate"] == "yes") {
			$smarty->assign('CFGEMAILERRORACTIVATE', "checked");
		}		
		if ($webcamboxconfig["cfgsourcegphotocalibration"] == "yes") {
			$smarty->assign('CFGSOURCEGPHOTOCALIBRATION', "checked");
		}		
		if ($webcamboxconfig["cfgsourcecamiplimiterotation"] == "yes") {
			$smarty->assign('CFGSOURCECAMIPLIMITEROTATION', "checked");
		}	
		if ($webcamboxconfig["cfgnocapture"] == "yes") {
			$smarty->assign('CFGNOCAPTURE', "checked");
		}
		$cfgsourcegphotocameramodel = $webcamboxconfig["cfgsourcegphotocameramodel"];
		if ($cfgsourcegphotocameramodel == "no") {
			$smarty->assign('CFGSOURCEGPHOTOCAMERAMODEL', "");
		} else {
			$smarty->assign('CFGSOURCEGPHOTOCAMERAMODEL', $webcamboxconfig["cfgsourcegphotocameramodel"] );		
		}
		$cfgsourcegphotocameraportdetail = $webcamboxconfig["cfgsourcegphotocameraportdetail"];
		if ($cfgsourcegphotocameraportdetail == "automatic") {
			$smarty->assign('CFGSOURCEGPHOTOCAMERAPORTDETAIL', "automatique");
		} else {
			$smarty->assign('CFGSOURCEGPHOTOCAMERAPORTDETAIL', $webcamboxconfig["cfgsourcegphotocameraportdetail"] );		
		}		
		$cfgsourcewebcamsize = $webcamboxconfig["cfgsourcewebcamsize"];
		if ($cfgsourcewebcamsize != "320x240" && $cfgsourcewebcamsize != "640x480" && $cfgsourcewebcamsize != "800x600" && $cfgsourcewebcamsize != "1024x768" && $cfgsourcewebcamsize != "1280x1024" && $cfgsourcewebcamsize != "1600x1200") {
			$smarty->assign('CFGSOURCEWEBCAMSIZE', 'autre');
			$smarty->assign('CFGSOURCEWEBCAMSIZEOTHER', $cfgsourcewebcamsize);
		} else {
			$smarty->assign('CFGSOURCEWEBCAMSIZE', $webcamboxconfig["cfgsourcewebcamsize"] );
		}
		$cfgsourcewebcamid = $webcamboxconfig["cfgsourcewebcamcamid"];
		//$smarty->assign('CFGSOURCEWEBCAMID', $cfgsourcewebcamid);
		$trans = array("video" => "", "dev" => "", "/" => "");
		$cfgsourcewebcamidnb = strtr($cfgsourcewebcamid, $trans);
		$cfgsourcewebcamidnb = $cfgsourcewebcamidnb * 1;
		
		if ($webcamboxconfig["cfgsourcetype"] == "webcam") {
			// Recuperation des parametres par défaut pour la webcam usb
			passthru("sudo -u " . $config_systemuser . " /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " v4lunique");
			$fd = @fopen("/tmp/v4lctl" . $cfgsourcewebcamidnb ,"r");
			if (!$fd) die("Erreur ouverture fichier: $fd");
			$i = 1; // compteur de ligne
			while (!feof($fd)) {
				$ligne = fgets($fd, 1024);
				if (stripos($ligne, $witoget . "bright") !== false) {
					list($webcamattribute, $webcamtype, $webcamcurrent, $webcamdefault, $webcamcomment) = explode("|", $ligne);
					$smarty->assign('CFGSOURCEWEBCAMBRIGHTATTRIBUTE', $webcamattribute);
					$smarty->assign('CFGSOURCEWEBCAMBRIGHTCURRENT', $webcamcurrent);
					$smarty->assign('CFGSOURCEWEBCAMBRIGHTDEFAULT', $webcamdefault);
					$smarty->assign('CFGSOURCEWEBCAMBRIGHTCOMMENT', $webcamcomment);		
				}			
				if (stripos($ligne, $witoget . "contrast") !== false) {
					list($webcamattribute, $webcamtype, $webcamcurrent, $webcamdefault, $webcamcomment) = explode("|", $ligne);
					$smarty->assign('CFGSOURCEWEBCAMCONTRASTATTRIBUTE', $webcamattribute);
					$smarty->assign('CFGSOURCEWEBCAMCONTRASTCURRENT', $webcamcurrent);
					$smarty->assign('CFGSOURCEWEBCAMCONTRASTDEFAULT', $webcamdefault);
					$smarty->assign('CFGSOURCEWEBCAMCONTRASTCOMMENT', $webcamcomment);		
				}
				if (stripos($ligne, $witoget . "color") !== false) {
					list($webcamattribute, $webcamtype, $webcamcurrent, $webcamdefault, $webcamcomment) = explode("|", $ligne);
					$smarty->assign('CFGSOURCEWEBCAMCOLORATTRIBUTE', $webcamattribute);
					$smarty->assign('CFGSOURCEWEBCAMCOLORCURRENT', $webcamcurrent);
					$smarty->assign('CFGSOURCEWEBCAMCOLORDEFAULT', $webcamdefault);
					$smarty->assign('CFGSOURCEWEBCAMCOLORCOMMENT', $webcamcomment);		
				}
				if (stripos($ligne, $witoget . "hue") !== false) {
					list($webcamattribute, $webcamtype, $webcamcurrent, $webcamdefault, $webcamcomment) = explode("|", $ligne);
					$smarty->assign('CFGSOURCEWEBCAMHUEATTRIBUTE', $webcamattribute);
					$smarty->assign('CFGSOURCEWEBCAMHUECURRENT', $webcamcurrent);
					$smarty->assign('CFGSOURCEWEBCAMHUEDEFAULT', $webcamdefault);
					$smarty->assign('CFGSOURCEWEBCAMHUECOMMENT', $webcamcomment);		
				}					
				//if (!feof($fd)) echo "Ligne $i : ".htmlEntities($ligne)."<br/>";
				$i++;
			}
			fclose($fd);
		}
		if ($webcamboxconfig["cfgsourcetype"] == "gphoto") {
			//Gphoto2 Ports
			//gphoto2 --auto-detect |egrep -o "usb:...,..."
			passthru("sudo -u " . $config_systemuser . " /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " gphoto2usbports");
			if (is_file("/tmp/gphoto2ports")) {
				$fd = @fopen("/tmp/gphoto2ports","r");	
				$cptports=0;
	   		while (!feof($fd)) {	
					$ligne = fgets($fd, 1024);
		      	if (!feof($fd)) {
		      		if ($ligne != "") {
		        			$gphotoports[$cptports] = trim($ligne);
		        			$cptports++;
		        		}
		         }
				}
				fclose($fd);
				$smarty->assign('CPTGPHOTOPORTS', $cptports);
				$smarty->assign('GPHOTOPORTS', $gphotoports);					
			}  		
			//$searchgphotoports = file_get_contents("/tmp/gphoto2ports");
			//echo "<pre>$searchgphotoports</pre>";
			//$smarty->assign('DISPGPHOTOPORTS', $searchgphotoports);
		}


if (is_file($config_langdir . "config-source.php")) {
	include($config_langdir . "config-source.php");
}
$smarty->assign('CONFIGPAGE', 'source');
$smarty->assign('CENTRAL', 'config-source.tpl');
$smarty->display('skeleton.tpl');
?>