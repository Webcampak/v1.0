<?php
// Copyright 2010 Infracom & Eurotechnia (support@webcampak.com)
// This file is part of the Webcampak project.
// Webcampak is free software: you can redistribute it and/or modify it 
// under the terms of the GNU General Public License as published by 
// the Free Software Foundation, either version 3 of the License, 
// or (at your option) any later version.

// Webcampak is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; 
// even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// See the GNU General Public License for more details.

// You should have received a copy of the GNU General Public License along with Webcampak. 
// If not, see http://www.gnu.org/licenses/.


require("../../etc/admin.config.php");
require("include/zip.lib.php");

$configsection = strip_tags($_GET['section']);
$smarty->assign('CONFIGSECTION', $configsection);

			//passthru("sudo /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " initconfsources");		 	
		 	//$smarty->assign('POSTINITCONFS1', 'Réinitialisation source 4 ... OK');

		if (strip_tags($_GET['openvpnstart']) == "1") {
			passthru("sudo /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " openvpnstart");		 		
		}
		if (strip_tags($_GET['openvpnstop']) == "1") {
			passthru("sudo /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " openvpnstop");		 				
		}
						
		if (strip_tags($_GET['submit']) == "1") {
			if (strip_tags($_POST['postinitconfcs']) == "yes"){
				$smarty->assign('POSTINITCONF', 'Réinitialisation de la configuration en cours ...');
				passthru("sudo -u " . $config_systemuser . " /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " initconfsources");		 	
				$smarty->assign('POSTINITCONFCS', 'Réinitialisation source ' . $config_source . ' ... OK');
			}
			 if (strip_tags($_POST['postinitcontentcs']) == "yes"){
			 	$smarty->assign('POSTINITCONTENT', 'Suppression des images et vidéos en cours ...');
				passthru("sudo -u " . $config_systemuser . " /usr/bin/php -f " . $config_bindirectory . "server.php -- " . $config_source . " initcontent");		
				$smarty->assign('POSTINITCONTENTCS', 'Réinitialisation source  ' . $config_source . ' ... OK'); 		 
			 }

			foreach ($_POST as $confkey=>$confvalue) {
				if (substr($confkey, 0, 3) == "cfg") {
					$witoparameters[strip_tags($confkey)] = strip_tags($confvalue);
				}
			}
			if (strip_tags($_POST["cfgemailsmtpauth"]) == "") { $witoparameters["cfgemailsmtpauth"] = "no";}
			if (strip_tags($_POST["cfgemailsmtpstartttls"]) == "") { $witoparameters["cfgemailsmtpstartttls"] = "no";}
			if (strip_tags($_POST["cfgphidgeterroractivate"]) == "") { $witoparameters["cfgphidgeterroractivate"] = "no";}
			if (strip_tags($_POST["cfgphidgetsensorsgraph"]) == "") { $witoparameters["cfgphidgetsensorsgraph"] = "no";}
			wito_writeconfig($config_witoconfig, $witoparameters);
		}
		if (strip_tags($_GET['upload']) == "1") { 
			if ($_FILES['configupload']['error'] == UPLOAD_ERR_OK) {
				move_uploaded_file($_FILES['configupload']['tmp_name'], $config_etcdirectory. "config-source" . $config_source . ".zip");
				$unzipfiles = unzip($config_etcdirectory. "config-source" . $config_source . ".zip", $config_etcdirectory, true, $config_source);
				if ($unzipfiles != FALSE) {
					$smarty->assign('UPLOADSUCCESSFUL', 'YES');
				}
			}
		}
		$webcamboxconfig = wito_getfullconfig($config_witoconfig);
		foreach ($webcamboxconfig as $readkey=>$readvalue) {
		      $smarty->assign(strtoupper($readkey), $readvalue);
		}
		if ($webcamboxconfig["cfgemailsmtpauth"] == "yes") {
			$smarty->assign('CFGEMAILSMTPAUTH', "checked");
		}
		if ($webcamboxconfig["cfgemailsmtpstartttls"] == "yes") {
			$smarty->assign('CFGEMAILSMTPSTARTTTLS', "checked");
		}
		if ($webcamboxconfig["cfgphidgeterroractivate"] == "yes") {
			$smarty->assign('CFGPHIDGETERRORACTIVATE', "checked");
		}
		if ($webcamboxconfig["cfgphidgetsensorsgraph"] == "yes") {
			$smarty->assign('CFGPHIDGETSENSORSGRAPH', "checked");
		}


if (is_file($config_langdir . "config-avance.php")) {
	include($config_langdir . "config-avance.php");
}
//$smarty->assign("BODYCONTENT", $smarty->template_dir . "index.tpl");
$smarty->assign('CONFIGPAGE', 'avance');
$smarty->assign('CENTRAL', 'config-avance.tpl');
$smarty->display('skeleton.tpl');
//$_COOKIE['lasturl'] = "panel.php"browserurl();



?>