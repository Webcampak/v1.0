<?php 
$smarty->assign('LANG_CONFIGAPPAREILS_TITLE', "Appareils Connectés");

$smarty->assign('LANG_CONFIGAPPAREILS_GPHOTOCONNECTED', "Appareils photo connectés (gphoto2)");
$smarty->assign('LANG_CONFIGAPPAREILS_GPHOTOCAPACITY', "Capacités Appareil(s) photo(s) (gphoto2)");
$smarty->assign('LANG_CONFIGAPPAREILS_USBDEVICES', "Périphériques USB (lsusb)");
$smarty->assign('LANG_CONFIGAPPAREILS_VIDEODEVICES', "Périphériques Videos, Webcams USB (/dev/video...)");
$smarty->assign('LANG_CONFIGAPPAREILS_VIDEODEVICES_ADVANCED', "Avancé - Périphériques Videos, Webcams USB (/dev/video...)");
 
?>