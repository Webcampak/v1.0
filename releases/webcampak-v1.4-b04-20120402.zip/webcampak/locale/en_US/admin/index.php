<?php 
$smarty->assign('LANG_INDEX_TITLE', "Dashboard");
$smarty->assign('LANG_INDEX_SOURCE_TITLE', "Source");
$smarty->assign('LANG_INDEX_SOURCE_AVAILABLESIZES', "Available sizes: ");
$smarty->assign('LANG_INDEX_SOURCE_NOPICTURES', "No picture currently available");

$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_STATUS', "Status");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_LASTCAPTURE', "Last Capture");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_DISKUSAGE', "Disk usage");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_TIME', "Time since last capture");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_FREQUENCY', "Frequency");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_LEGEND', "Legend");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_DISKPICTURES', "Pictures");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_DISKVIDEOS', "Videos");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_DISKTOTAL', "Total");


?>