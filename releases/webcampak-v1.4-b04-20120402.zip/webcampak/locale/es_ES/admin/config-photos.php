<?php 
$smarty->assign('LANG_PHOTOS_SOURCE', "Fuente");
$smarty->assign('LANG_PHOTOS_TITLE', ": Configuración de fotografías");
$smarty->assign('LANG_PHOTOS_TIP', "Consejo:");

$smarty->assign('LANG_PHOTOS_TIME_TITLE', "Periodo de captura");
$smarty->assign('LANG_PHOTOS_TIME_NORESTRICTIONS', "Sin restricciones en el periodo de captura:");
$smarty->assign('LANG_PHOTOS_TIME_START', "Comenzar la captura a las:");
$smarty->assign('LANG_PHOTOS_TIME_END', "Terminar la captura a las:");
$smarty->assign('LANG_PHOTOS_TYPE_CAPTUREDELAYDATE', "Fecha de imagen:");
$smarty->assign('LANG_PHOTOS_TYPE_CAPTUREDELAYDATECAPTURE', "Hora de captura");
$smarty->assign('LANG_PHOTOS_TYPE_CAPTUREDELAYDATESCRIPT', "Hora de comienzo del script");
  
$smarty->assign('LANG_PHOTOS_CROP_TITLE', "Recortar");
$smarty->assign('LANG_PHOTOS_CROP_ACTIVATE', "Recortar imágenes:");
$smarty->assign('LANG_PHOTOS_CROP_SIZE', "Tamaño del área:");
$smarty->assign('LANG_PHOTOS_CROP_LOCATION', "Posición:");

$smarty->assign('LANG_PHOTOS_LEGEND_TITLE', "Leyenda");
$smarty->assign('LANG_PHOTOS_LEGEND_ACTIVATE', "Insertar leyenda en la fotografía:");
$smarty->assign('LANG_PHOTOS_LEGEND_LEGEND', "Leyenda:");
$smarty->assign('LANG_PHOTOS_LEGEND_FORMAT', "Formato de fecha:");
$smarty->assign('LANG_PHOTOS_LEGEND_NODATE', "Sin fecha");
$smarty->assign('LANG_PHOTOS_LEGEND_FORMAT4', "Jueves 25 de enero de 2010 - 09h30");
$smarty->assign('LANG_PHOTOS_LEGEND_FORMAT5', "25 de enero de 2010 - 09h30");
$smarty->assign('LANG_PHOTOS_LEGEND_ADVANCED', "Configuración de texto avanzado:");
$smarty->assign('LANG_PHOTOS_LEGEND_FONTSIZE', "Tamaño de fuente:");
$smarty->assign('LANG_PHOTOS_LEGEND_FONTLOCATION', "Posición del texto:");
$smarty->assign('LANG_PHOTOS_LEGEND_FONTSOUTHWEST', "Inferior izquierda");
$smarty->assign('LANG_PHOTOS_LEGEND_FONTSOUTH', "Inferior centro");
$smarty->assign('LANG_PHOTOS_LEGEND_FONTSOUTHEAST', "Inferior derecha");
$smarty->assign('LANG_PHOTOS_LEGEND_FONTEAST', "Centro derecha");
$smarty->assign('LANG_PHOTOS_LEGEND_FONTNORTHEAST', "Superior derecha");
$smarty->assign('LANG_PHOTOS_LEGEND_FONTNORTH', "Superior centro");
$smarty->assign('LANG_PHOTOS_LEGEND_FONTNORTWEST', "Superior izquierda");
$smarty->assign('LANG_PHOTOS_LEGEND_FONTWEST', "Centro izquierda");
$smarty->assign('LANG_PHOTOS_LEGEND_FONTNAME', "Fuente:");
$smarty->assign('LANG_PHOTOS_LEGEND_FONTSHADOWCOLOR', "Color de sombra:");
$smarty->assign('LANG_PHOTOS_LEGEND_FONTSHADOWCOORDINATES', "Posición de la sombra:");
$smarty->assign('LANG_PHOTOS_LEGEND_FONTCOLOR', "Color de fuente:");
$smarty->assign('LANG_PHOTOS_LEGEND_FONTCOORDINATES', "Posición del texto:");

$smarty->assign('LANG_PHOTOS_WATERMARK_TITLE', "Insertar Watermark (incrustrar imagen en la fotografía)");
$smarty->assign('LANG_PHOTOS_WATERMARK_ACTIVATE', "Insertar un watermark en la fotografía:");
$smarty->assign('LANG_PHOTOS_WATERMARK_SOURCE', "Archivo Watermark:");
$smarty->assign('LANG_PHOTOS_WATERMARK_TRANSPARENCY', "Transparencia:");
$smarty->assign('LANG_PHOTOS_WATERMARK_XCOORDINATE', "Posición horizontal (X):");
$smarty->assign('LANG_PHOTOS_WATERMARK_YCOORDINATE', "Posición vertical (Y):");
$smarty->assign('LANG_PHOTOS_WATERMARK_TIP', "Los archivos Watermark deben estar en formato 'PNG' y estar ubicados en la carpeta /watermark/ a través de la cuenta global FTP(via Sistema tab), esta carpeta se comparte entre todas las fuentes. <br />	El punto de comienzo de posición corresponde a la esquina superior izquierda de la fotograía <br /> <strong>Aviso:</strong> El nombre de archivo no debe contener espacios con caracteres especiales.");

$smarty->assign('LANG_PHOTOS_PHIDGET_TITLE', "Insertar medidas de sensores Phidget");
$smarty->assign('LANG_PHOTOS_PHIDGET_TEMPERATURE_ACTIVATE', "Insertar la temperatura en la fotografía");
$smarty->assign('LANG_PHOTOS_PHIDGET_TEMPERATURE_SIZE', "Insertar tamaño (por ejemplo: 320x240)");
$smarty->assign('LANG_PHOTOS_PHIDGET_TEMPERATURE_DISSOLVE', "Transparencia:");
$smarty->assign('LANG_PHOTOS_PHIDGET_TEMPERATURE_XCOORDINATE', "Posición horizontal (X):");
$smarty->assign('LANG_PHOTOS_PHIDGET_TEMPERATURE_YCOORDINATE', "Posición vertical (Y):");
$smarty->assign('LANG_PHOTOS_PHIDGET_LUMINOSITY_ACTIVATE', "Insertar luminosidad dentro de la fotografía");
$smarty->assign('LANG_PHOTOS_PHIDGET_LUMINOSITY_SIZE', "Insertar tamaño(por ejemplo: 320x240)");
$smarty->assign('LANG_PHOTOS_PHIDGET_LUMINOSITY_DISSOLVE', "Transparencia:");
$smarty->assign('LANG_PHOTOS_PHIDGET_LUMINOSITY_XCOORDINATE', "Posición horizontal (X):");
$smarty->assign('LANG_PHOTOS_PHIDGET_LUMINOSITY_YCOORDINATE', "Posición vertical (Y):");

$smarty->assign('LANG_PHOTOS_ARCHIVES_TITLE', "Archivos");
$smarty->assign('LANG_PHOTOS_ARCHIVES_ACTIVATE', "Guardar fotografías en los archivos:");
$smarty->assign('LANG_PHOTOS_ARCHIVES_WARNING', "Aviso, si la opción guardar fotografías no está activada no será posible generar videos.");
$smarty->assign('LANG_PHOTOS_ARCHIVES_RESIZEACTIVATE', "Cambiar el tamaño de las fotografías antes de guardarlas en los archivos:");
$smarty->assign('LANG_PHOTOS_ARCHIVES_RESIZESIZE', "Tamaño nuevo (por ejemplo: 1024x768):");
$smarty->assign('LANG_PHOTOS_ARCHIVES_PICSIZE', "Tamaño mínimo de las fotografías:");
$smarty->assign('LANG_PHOTOS_ARCHIVES_PICDELETE', "Fotografías con tamaño inferior a éste serán borradas automáticamente.");
$smarty->assign('LANG_PHOTOS_ARCHIVES_DELETEPICAFTER', "Borrar fotografías después de:");
$smarty->assign('LANG_PHOTOS_ARCHIVES_DAYS', "días");
$smarty->assign('LANG_PHOTOS_ARCHIVES_DELETEPICAFTERDELETE', "0 = sin límite. Una vez las fotografías se borran no es posible generar videos de los días correspondientes.");
$smarty->assign('LANG_PHOTOS_ARCHIVES_MAXSIZE', "Tamaño máximo de arhivo:");
$smarty->assign('LANG_PHOTOS_ARCHIVES_MB', "Mbytes");
$smarty->assign('LANG_PHOTOS_ARCHIVES_MAXSIZEDELETE', "0 = sin límite. Sobre este valor, el último día de de captura será eliminado automáticamente.");

$smarty->assign('LANG_PHOTOS_HOTLINK_TITLE', "Fotografías estáticas (hotlink)");
$smarty->assign('LANG_PHOTOS_HOTLINK_RESIZE', "Cambiar el tamaño de las fotografías:");
$smarty->assign('LANG_PHOTOS_HOTLINK_IFOTHER', "Por favor especifique si es otro:");
$smarty->assign('LANG_PHOTOS_HOTLINK_OTHERSIZES', "Otro tamaño");
$smarty->assign('LANG_PHOTOS_HOTLINK_DISABLED', "Deshabilitado");
$smarty->assign('LANG_PHOTOS_HOTLINK_FORMAT1', "Archivo 1:");
$smarty->assign('LANG_PHOTOS_HOTLINK_FORMAT2', "Archivo 2:");
$smarty->assign('LANG_PHOTOS_HOTLINK_FORMAT3', "Archivo 3:");
$smarty->assign('LANG_PHOTOS_HOTLINK_FORMAT4', "Archivo 4:");
$smarty->assign('LANG_PHOTOS_HOTLINKERROR_ACTIVATE', "Generate hotlink image in case of capture error:");
$smarty->assign('LANG_PHOTOS_HOTLINK_TIP', "Una fotografía o video estático es un archivo cuyo nombre es siempre el mismo, sólo cambia el contenido. Estas fotografías puede utilizarse en una página web que muestre por ejemplo una cámara web. <br />");

$smarty->assign('LANG_PHOTOS_BUTTON', "Guardar");

?>