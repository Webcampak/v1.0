<?php 
$smarty->assign('LANG_WEBMIN_TITLE', "Administración del sistema");
$smarty->assign('LANG_WEBMIN_DESCRIPTION', "Webmin es una herramienta de administración del sistema, puede utilizarla para modificar los parámetros del sistema.<br/>");
 
?>