<?php 
//<!--{$LANG_VIDEOS_DAILYVID}-->
$smarty->assign('LANG_VIDEOS_DAILYVID', "Video(s) of the day:");
$smarty->assign('LANG_VIDEOS_DAILYCREATEDVID', "Video(s) created this day:");
$smarty->assign('LANG_VIDEOS_DOWNLOADVID', "Downl. video");


$smarty->assign('LANG_VIDEOS_NOPREVIEW', "Preview not available. <br />Select 'Web' option in the administration panel.");
  					


?>