<?php 
$smarty->assign('LANG_SYSTEMLOGS_TITLE', "Logos del sistema");
$smarty->assign('LANG_SYSTEMLOGS_TIP', "Acciones iniciadas por los usuarios a través del panel de control");

 

?>