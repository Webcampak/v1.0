<?php 
$smarty->assign('LANG_REBOOT_TITLE', "Reiniciar webcampak");
$smarty->assign('LANG_REBOOT_REBOOT', "Reiniciar");
$smarty->assign('LANG_REBOOT_AREYOUSURE', "¿Está seguro de que desea reiniciar el sistema ?");
$smarty->assign('LANG_REBOOT_NOW', "(Reiniciar ahora)");

 

?>