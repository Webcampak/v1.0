<?php 
$smarty->assign('LANG_WEBMIN_TITLE', "System Administration");
$smarty->assign('LANG_WEBMIN_DESCRIPTION', "Webmin is a system administration tool, you can use it to modify system parameters.<br/>");

?>