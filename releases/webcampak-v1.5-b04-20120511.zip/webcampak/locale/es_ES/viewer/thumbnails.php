<?php 
//<!--{$LANG_THUMBNAILS_NOPICTURE}-->
$smarty->assign('LANG_THUMBNAILS_SOURCE', "Fuente:");
$smarty->assign('LANG_THUMBNAILS_AVAILABLESIZES', "Tamaños disponibles:");
$smarty->assign('LANG_THUMBNAILS_NOPICTURE', "No hay imagen disponible");
$smarty->assign('LANG_THUMBNAILS_SLIDESHOW', "Start slideshow");


?>
