<?php 
$smarty->assign('LANG_MANAGEPICTURES_SOURCE', "Source");
$smarty->assign('LANG_MANAGEPICTURES_TITLE', ": Images Archivées");
$smarty->assign('LANG_MANAGEPICTURES_TIP', "Astuce:");
$smarty->assign('LANG_MANAGEPICTURES_DELETE', "Supprimer");

$smarty->assign('LANG_MANAGEPICTURES_MANAGE', "Gestion des images archivées");
$smarty->assign('LANG_MANAGEPICTURES_DATE', "Date");
$smarty->assign('LANG_MANAGEPICTURES_NBPICS', "Nb. Images");
$smarty->assign('LANG_MANAGEPICTURES_GLOBALSIZE', "Taille Totale");
$smarty->assign('LANG_MANAGEPICTURES_TOTAL', "TOTAL");
$smarty->assign('LANG_MANAGEPICTURES_TIPCONTENT', "Cette page vous permet de supprimer une journée complète d'archives.<br />Pour ne supprimer que certaines photos connectez vous sur le webcampak en FTP.");



?>