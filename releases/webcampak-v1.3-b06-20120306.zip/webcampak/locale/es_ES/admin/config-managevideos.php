<?php 
$smarty->assign('LANG_MANAGEVIDEOS_SOURCE', "Fuente");
$smarty->assign('LANG_MANAGEVIDEOS_TITLE', ": Videos guardados");
$smarty->assign('LANG_MANAGEVIDEOS_TIP', "Consejo:");
 
$smarty->assign('LANG_MANAGEVIDEOS_MANAGE', "Administrar videos guardados");
$smarty->assign('LANG_MANAGEVIDEOS_DATE', "Fecha");
$smarty->assign('LANG_MANAGEVIDEOS_BUTTON', "Eliminar.");

?>