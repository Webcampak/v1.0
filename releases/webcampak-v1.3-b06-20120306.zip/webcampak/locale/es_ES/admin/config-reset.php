<?php 
$smarty->assign('LANG_RESET_TITLE', "Reiniciar el sistema");
$smarty->assign('LANG_RESET_ALLSOURCES', "Reiniciar todas las fuentes:");
$smarty->assign('LANG_RESET_ALLSOURCESTXT', "Reiniciar todas las fuentes de configuración:");
$smarty->assign('LANG_RESET_ALLSOURCESBUTTON', "Reiniciar la configuración para todas las fuentes");
$smarty->assign('LANG_RESET_ALLCONTENT', "Borrar todas las fotografías y videos);
$smarty->assign('LANG_RESET_ALLCONTENTBUTTON', "Borrar todas las fotografías y videos");
$smarty->assign('LANG_RESET_WARNING', "<strong><font color='red'>Aviso:</strong> Estas acciones son definitivas</font><br/><br/>Si desea hacer cambios en un única fuente por favor visite la sección avanzada de la fuente correspondiente.");

 

?>