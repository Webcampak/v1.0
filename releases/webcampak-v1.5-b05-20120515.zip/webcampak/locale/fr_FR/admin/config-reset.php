<?php 
$smarty->assign('LANG_RESET_TITLE', "Réinitialisation du système");
$smarty->assign('LANG_RESET_ALLSOURCES', "Réinitialiser (toutes les sources):");
$smarty->assign('LANG_RESET_ALLSOURCESTXT', "Réinitialiser la configuration pour l'ensemble des sources:");
$smarty->assign('LANG_RESET_ALLSOURCESBUTTON', "Réinitialiser toutes les sources");
$smarty->assign('LANG_RESET_ALLCONTENT', "Effacer l'ensemble des photos et videos:");
$smarty->assign('LANG_RESET_ALLCONTENTBUTTON', "Effacer l'ensemble des images et vidéos");
$smarty->assign('LANG_RESET_WARNING', "<strong><font color='red'>Attention:</strong> toute action est définitive</font><br/><br/>Si vous souhaitez modifier les informations liées à une source uniquement, reportez-vous à la section 'Avancé' de la source concernée.");



?>