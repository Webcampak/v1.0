<?php 
$smarty->assign('LANG_INDEX_TITLE', "Tableau de bord");
$smarty->assign('LANG_INDEX_SOURCE_TITLE', "Source");
$smarty->assign('LANG_INDEX_SOURCE_AVAILABLESIZES', "Résolutions disponibles: ");
$smarty->assign('LANG_INDEX_SOURCE_NOPICTURES', "Aucun cliché actuellement disponible");

$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_STATUS', "État");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_LASTCAPTURE', "Dernière Capture");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_DISKUSAGE', "Utilisation disque");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_TIME', "Temps écoulé");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_FREQUENCY', "Fréquence");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_LEGEND', "Légende");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_DISKPICTURES', "Images");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_DISKVIDEOS', "Vidéos");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_DISKTOTAL', "Total");
?>