<?php 
$smarty->assign('LANG_INDEX_TITLE', "Dashboard");
$smarty->assign('LANG_INDEX_SOURCE_TITLE', "Fuerntes");
$smarty->assign('LANG_INDEX_SOURCE_AVAILABLESIZES', "Tamaños disponibles: ");
$smarty->assign('LANG_INDEX_SOURCE_NOPICTURES', "Ninguna fotografía disponible en este momento");

$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_STATUS', "Status");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_LASTCAPTURE', "Last Capture");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_DISKUSAGE', "Disk usage");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_TIME', "Time since last capture");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_FREQUENCY', "Frequency");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_LEGEND', "Legend");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_DISKPICTURES', "Pictures");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_DISKVIDEOS', "Videos");
$smarty->assign('LANG_INDEX_SOURCE_DASHBOARD_DISKTOTAL', "Total");


?>